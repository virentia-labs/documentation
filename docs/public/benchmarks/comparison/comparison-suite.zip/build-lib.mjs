// Shared esbuild config: virentia aliased to the working-tree sources (production, minified).
import path from "node:path";
import { build } from "esbuild";
import fs from "node:fs";
export const root = path.dirname(new URL(import.meta.url).pathname);
// Virentia sources: $VIRENTIA_PACKAGES, else ../virentia/packages (suite next to the repo), else ./virentia-src/packages.
const packagesDir = process.env.VIRENTIA_PACKAGES
  ?? [path.join(root, "../virentia/packages"), path.join(root, "virentia-src/packages")].find((p) => fs.existsSync(path.join(p, "core/lib/index.ts")));
if (!packagesDir) throw new Error("Set VIRENTIA_PACKAGES=/path/to/virentia/packages");
const pkg = (f) => path.join(packagesDir, f);
export const alias = {
  "@virentia/ui/jsx-runtime": pkg("ui/lib/jsx-runtime.ts"),
  "@virentia/ui": pkg("ui/lib/index.ts"),
  "@virentia/core/models": pkg("core/lib/models.ts"),
  "@virentia/core/internal": pkg("core/lib/internal.ts"),
  "@virentia/core": pkg("core/lib/index.ts"),
  "@virentia/mutable": pkg("mutable/lib/index.ts"),
};
export async function bundle(entry, outfile, { platform = "node", define = {}, minify = true, jsx, plugins = [], sourcemap = false } = {}) {
  await build({
    entryPoints: [entry], outfile, bundle: true, platform, format: "esm",
    target: platform === "node" ? "node22" : "es2022", minify, sourcemap,
    define: { "process.env.NODE_ENV": '"production"', __DEV__: "false", ...define },
    alias, nodePaths: [path.join(root, "node_modules")], logLevel: "warning", plugins,
    ...(jsx ? jsx : {}),
  });
}
