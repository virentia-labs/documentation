// Builds one production bundle per framework: harness + app.
import { build } from "esbuild";
import { transformAsync } from "@babel/core";
import { compile as vueCompile } from "@vue/compiler-dom";
import { parse as sfcParse, compileScript } from "vue/compiler-sfc";
import { parse as vaporSfcParse, compileScript as vaporCompileScript } from "vue-vapor/compiler-sfc";
import fs from "node:fs";
import path from "node:path";
import { alias } from "../build-lib.mjs";
const here = path.dirname(new URL(import.meta.url).pathname);
const out = path.join(here, "dist");
fs.mkdirSync(out, { recursive: true });

const solidPlugin = {
  name: "solid-jsx",
  setup(b) {
    b.onLoad({ filter: /apps[/\\]solid.*\.tsx$/ }, async (args) => {
      const src = await fs.promises.readFile(args.path, "utf8");
      const res = await transformAsync(src, {
        filename: args.path,
        presets: [["babel-preset-solid", { generate: "dom" }], ["@babel/preset-typescript", { isTSX: true, allExtensions: true }]].filter(Boolean),
      });
      return { contents: res.code, loader: "js" };
    });
  },
};
// `import tpl from "./x.vue.html"` -> compiled Vue render function (same as SFC template compilation).
const vueTemplatePlugin = {
  name: "vue-template",
  setup(b) {
    b.onLoad({ filter: /\.vue\.html$/ }, async (args) => {
      const src = await fs.promises.readFile(args.path, "utf8");
      const { code } = vueCompile(src.trim(), { mode: "module", prefixIdentifiers: true, hoistStatic: true, cacheHandlers: true });
      return { contents: code, loader: "js", resolveDir: path.dirname(args.path) };
    });
  },
};

// Production SFC compilation (what @vitejs/plugin-vue does): <script setup> + inlined template.
const vueSfcPlugin = {
  name: "vue-sfc",
  setup(b) {
    b.onLoad({ filter: /\.vue$/ }, async (args) => {
      const src = await fs.promises.readFile(args.path, "utf8");
      // Vapor SFCs compile with Vue 3.6's compiler (the `vue-vapor` alias).
      const vapor = /apps[/\\]vue-vapor[/\\]/.test(args.path);
      const { descriptor, errors } = (vapor ? vaporSfcParse : sfcParse)(src, { filename: args.path });
      if (errors.length) throw errors[0];
      const id = path.basename(args.path).replace(/\W/g, "");
      const script = (vapor ? vaporCompileScript : compileScript)(descriptor, { id, inlineTemplate: true, isProd: true, templateOptions: { compilerOptions: { hoistStatic: true, cacheHandlers: true } } });
      return { contents: script.content, loader: "ts", resolveDir: path.dirname(args.path) };
    });
  },
};
// VIRENTIA_TEMPLATES=1: compile the Virentia apps' JSX into templates, as @virentia/ui/vite does.
async function templatesPlugin() {
  const packages = path.resolve(path.dirname(alias["@virentia/ui"]), "../..");
  const entry = path.join(here, ".templates-entry.mjs");
  const compiler = path.join(here, `.templates-compiler-${process.pid}.mjs`);
  fs.writeFileSync(entry, `export { addTemplateEdits } from ${JSON.stringify(path.join(packages, "ui/compiler/templates.ts"))};\nexport { SourceEdits } from ${JSON.stringify(path.join(packages, "core/compiler/edits.ts"))};\n`);
  await build({ entryPoints: [entry], outfile: compiler, bundle: true, format: "esm", platform: "node", logLevel: "warning" });
  const { addTemplateEdits, SourceEdits } = await import(compiler);
  fs.rmSync(entry);
  fs.rmSync(compiler);
  const { parseSync } = await import(path.join(packages, "ui/node_modules/vite/dist/node/index.js"));
  return {
    name: "virentia-templates",
    setup(b) {
      b.onLoad({ filter: /apps[/\\]virentia[^/\\]*\.tsx$/ }, async (args) => {
        const source = await fs.promises.readFile(args.path, "utf8");
        const { program, errors } = parseSync(args.path, source, { lang: "tsx", sourceType: "module" });
        if (errors.length) throw new Error(errors[0].message);
        const edits = new SourceEdits(source);
        const count = addTemplateEdits(program, source, edits);
        console.log("templates", path.basename(args.path), count);
        return { contents: edits.apply(args.path).code, loader: "tsx", resolveDir: path.dirname(args.path) };
      });
    },
  };
}
const extraPlugins = process.env.VIRENTIA_TEMPLATES === "1" ? [await templatesPlugin()] : [];

const variants = {
  virentia: { app: "./apps/virentia.tsx", jsx: { jsx: "automatic", jsxImportSource: "@virentia/ui" } },
  react: { app: "./apps/react.tsx", jsx: { jsx: "automatic", jsxImportSource: "react" } },
  vue: { app: "./apps/vue.ts" },
  // Vue 3.6 (release candidate) with Vapor mode, bundled with its own runtime.
  "vue-vapor": { app: "./apps/vue-vapor.ts", alias: { vue: "vue-vapor" } },
  "vue-inline": { app: "./apps/vue-inline.ts" },
  solid: { app: "./apps/solid.tsx" },
  vanilla: { app: "./apps/vanilla.ts" },
  mol: { app: "./apps/mol.tsx", jsx: { jsx: "transform", jsxFactory: "$mol_jsx", jsxFragment: "$mol_jsx_frag" } },
};
const only = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const profileBuild = process.argv.includes("--profile");
for (const [name, v] of Object.entries(variants)) {
  if (only.length && !only.includes(name)) continue;
  if (!fs.existsSync(path.join(here, v.app))) { console.log("skip", name); continue; }
  const entry = path.join(here, `.entry-${name}.ts`);
  fs.writeFileSync(entry, `import { app } from ${JSON.stringify(v.app)};\nimport { install } from "./harness";\ninstall(app);\n`);
  await build({
    entryPoints: [entry], outfile: path.join(out, `${name}${profileBuild ? "-prof" : ""}.js`), bundle: true, format: "esm", platform: "browser",
    target: "es2022", minify: !profileBuild, keepNames: profileBuild && !process.env.NOKEEP, legalComments: "none",
    define: { "process.env.NODE_ENV": '"production"', __DEV__: "false", __VUE_OPTIONS_API__: "false", __VUE_PROD_DEVTOOLS__: "false", __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: "false" },
    alias: { ...alias, ...(v.alias ?? {}) }, nodePaths: [path.join(here, "../node_modules")], logLevel: "warning",
    plugins: [...extraPlugins, solidPlugin, vueTemplatePlugin, vueSfcPlugin],
    ...(v.jsx ?? {}),
  });
  fs.rmSync(entry);
  console.log("built", name + (profileBuild ? "-prof" : ""), (fs.statSync(path.join(out, `${name}${profileBuild ? "-prof" : ""}.js`)).size / 1024).toFixed(1) + " KiB");
}
