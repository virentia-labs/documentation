// Runs UI benchmarks in Chromium (Playwright). One fresh browser context per (framework, scenario, size).
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = await import("playwright");
const here = path.dirname(new URL(import.meta.url).pathname);

const css = `body{font:14px/1.4 system-ui,sans-serif;margin:0}#main{padding:8px}
table{border-collapse:collapse;width:100%}td{border-top:1px solid #ddd;padding:4px 8px}
.col-md-1{width:8%}.col-md-4{width:33%}.col-md-6{width:50%}tr.danger{background:#f2dede}
.glyphicon{display:inline-block;width:12px;height:12px;background:#c33}a{cursor:pointer;color:#337ab7}`;
const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  if (url.pathname.startsWith("/dist/")) {
    res.setHeader("content-type", "text/javascript");
    res.end(fs.readFileSync(path.join(here, url.pathname)));
    return;
  }
  const fw = url.searchParams.get("fw");
  res.setHeader("content-type", "text/html");
  res.end(`<!doctype html><html><head><meta charset="utf-8"><style>${css}</style></head><body><div id="main"></div><script type="module" src="/dist/${fw}.js"></script></body></html>`);
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const base = `http://127.0.0.1:${server.address().port}`;

const args = Object.fromEntries(process.argv.slice(2).map((a) => a.split("=")));
const frameworks = (args.fw ?? "virentia,react,vue,solid,mol").split(",");
const scenarios = (args.scenario ?? "A,B").split(",");
const sizes = (args.n ?? "1000,10000").split(",").map(Number);
const verifyOnly = args.verify === "1";
const outFile = args.out ?? path.join(here, "../results/ui-raw.json");
const plan = (n) => n >= 10000 ? { warmup: Number(args.warmupL ?? 3), rounds: Number(args.roundsL ?? 10) }
                               : { warmup: Number(args.warmupM ?? 5), rounds: Number(args.roundsM ?? 20) };

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH,
  args: [`--js-flags=--expose-gc ${process.env.JSFLAGS ?? ""}`, "--enable-precise-memory-info", "--disable-background-timer-throttling",
         "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows", "--no-sandbox"],
});
const results = fs.existsSync(outFile) && args.append === "1" ? JSON.parse(fs.readFileSync(outFile, "utf8")) : { meta: {}, runs: [] };
results.meta = { browser: browser.version(), date: new Date().toISOString(), node: process.version };
async function openPage(fw) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") errors.push(m.type() + ": " + m.text()); });
  await page.goto(`${base}/?fw=${fw}`);
  await page.waitForFunction(() => globalThis.benchReady === true, null, { timeout: 30000 });
  if (args.nogc === "1") await page.evaluate(() => { globalThis.benchNoGC = true; });
  return { context, page, errors };
}
try {
  for (const fw of frameworks) {
    const { context, page, errors } = await openPage(fw);
    const v = await page.evaluate(() => globalThis.benchVerify());
    console.log(`[verify] ${fw}:`, JSON.stringify(v), errors.length ? "console: " + errors.slice(0, 3).join(" | ") : "");
    results.runs.push({ fw, verify: v, consoleErrors: errors.slice(0, 10) });
    await context.close();
  }
  if (!verifyOnly) {
    // Interleave frameworks inside each (scenario,size) to spread temporal noise.
    for (const n of sizes) for (const scenario of scenarios) for (const fw of frameworks) {
      const { context, page, errors } = await openPage(fw);
      const cfg = { scenario, n, ...plan(n) };
      const t = Date.now();
      try {
        const r = await page.evaluate((c) => globalThis.benchRun(c), cfg);
        const warm = r.samples.filter((s) => s.warm);
        const med = (k) => { const a = warm.map((s) => s[k]).sort((x, y) => x - y); return a[Math.floor(a.length / 2)]; };
        console.log(`${fw.padEnd(15)} ${scenario} n=${String(n).padEnd(6)} mount ${med("mount").toFixed(1).padStart(8)}  +layout ${med("mountLayout").toFixed(1).padStart(8)}  unmount ${med("unmount").toFixed(1).padStart(8)}  heap ${med("heapMountedMB").toFixed(2).padStart(7)}MB  leak ${med("heapLeakMB").toFixed(2).padStart(6)}MB  cold ${r.samples[0].mount.toFixed(1)}  (${((Date.now() - t) / 1000).toFixed(0)}s)`);
        results.runs.push({ fw, ...r, consoleErrors: errors.slice(0, 10) });
      } catch (e) {
        console.log(`${fw} ${scenario} n=${n} FAILED: ${String(e).slice(0, 400)}`);
        results.runs.push({ fw, scenario, n, error: String(e) });
      }
      await context.close();
      fs.writeFileSync(outFile, JSON.stringify(results, null, 1));
    }
  }
} finally {
  await browser.close();
  server.close();
}
