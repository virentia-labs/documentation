// Deterministic js-framework-benchmark-style data shared by all frameworks.
export interface RowData { id: number; label: string }
const A = ["pretty","large","big","small","tall","short","long","handsome","plain","quaint","clean","elegant","easy","angry","crazy","helpful","mushy","odd","unsightly","adorable","important","inexpensive","cheap","expensive","fancy"];
const C = ["red","yellow","blue","green","pink","brown","purple","brown","white","black","orange"];
const N = ["table","chair","house","bbq","desk","car","pony","cookie","sandwich","burger","pizza","mouse","keyboard"];
let seed = 1;
const rnd = (max: number) => { seed = (seed * 16807) % 2147483647; return seed % max; };
export function resetSeed() { seed = 1; }
let nextId = 1;
export function buildData(count: number): RowData[] {
  const data = new Array<RowData>(count);
  for (let i = 0; i < count; i++)
    data[i] = { id: nextId++, label: `${A[rnd(A.length)]} ${C[rnd(C.length)]} ${N[rnd(N.length)]}` };
  return data;
}
export interface BenchApp {
  name: string;
  version: string;
  /** Scenario A: mount a fresh root with all rows; unmount the root. */
  mountA(container: HTMLElement, data: RowData[]): void | Promise<void>;
  unmountA(): void | Promise<void>;
  /** Scenario B: app is already mounted with an empty list; create / clear rows via state. */
  initB(container: HTMLElement): void | Promise<void>;
  createB(data: RowData[]): void | Promise<void>;
  clearB(): void | Promise<void>;
  disposeB(): void | Promise<void>;
  /** Verification/updates (work in whichever scenario is mounted). */
  updateEvery10th(): void | Promise<void>;
  /** Scenario C ("light rows", mirrors the repo's own ui.harness): <tr><td>id</td><td>{count}</td></tr>, per-row state. */
  mountC?(container: HTMLElement, n: number): void | Promise<void>;
  updateC?(value: number): void | Promise<void>;
  unmountC?(): void | Promise<void>;
  /** Flush pending async framework work after a DOM event (click). */
  flush?(): void | Promise<void>;
}
