<script setup lang="ts">
import { ref } from "vue";
const props = defineProps<{ item: { id: number; label: string } }>();
const emit = defineEmits<{ remove: [id: number] }>();
const selected = ref(false);
</script>
<template>
  <tr :class="selected ? 'danger' : ''">
    <td class="col-md-1">{{ item.id }}</td>
    <td class="col-md-4"><a @click="selected = !selected">{{ item.label }}</a></td>
    <td class="col-md-1"><a @click="emit('remove', item.id)"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>
    <td class="col-md-6"></td>
  </tr>
</template>
