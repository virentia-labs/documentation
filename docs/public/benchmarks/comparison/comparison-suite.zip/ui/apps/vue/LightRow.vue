<script setup lang="ts">
import { shallowRef } from "vue";
const props = defineProps<{ id: number; reg: (id: number, r: { value: number }) => void }>();
const count = shallowRef(0);
props.reg(props.id, count);
</script>
<template><tr><td>{{ id }}</td><td>{{ count }}</td></tr></template>
