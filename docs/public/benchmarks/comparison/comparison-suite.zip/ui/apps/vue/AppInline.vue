<script setup lang="ts">
import { shallowRef, ref, triggerRef } from "vue";
// js-framework-benchmark style: one component, v-for rows, shallowRef + triggerRef.
const props = defineProps<{ initial: { id: number; label: string }[]; api: Record<string, unknown> }>();
const rows = shallowRef(props.initial.map((d) => ({ ...d, selected: false })));
props.api.rows = rows;
props.api.trigger = () => triggerRef(rows);
const toggle = (row: { selected: boolean }) => { row.selected = !row.selected; triggerRef(rows); };
const remove = (id: number) => { rows.value = rows.value.filter((r) => r.id !== id); };
</script>
<template>
  <table class="table table-hover table-striped test-data">
    <tbody>
      <tr v-for="row in rows" :key="row.id" :class="row.selected ? 'danger' : ''">
        <td class="col-md-1">{{ row.id }}</td>
        <td class="col-md-4"><a @click="toggle(row)">{{ row.label }}</a></td>
        <td class="col-md-1"><a @click="remove(row.id)"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>
        <td class="col-md-6"></td>
      </tr>
    </tbody>
  </table>
</template>
