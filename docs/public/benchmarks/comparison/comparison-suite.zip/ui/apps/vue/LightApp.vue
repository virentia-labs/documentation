<script setup lang="ts">
import LightRow from "./LightRow.vue";
defineProps<{ ids: number[]; reg: (id: number, r: { value: number }) => void }>();
</script>
<template><table><tbody><LightRow v-for="id in ids" :key="id" :id="id" :reg="reg" /></tbody></table></template>
