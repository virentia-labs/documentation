// Vue 3.6 Vapor mode: the same SFCs with <script setup vapor>, compiled to Vapor (no virtual DOM), Row component per row.
import { createVaporApp as createApp, nextTick } from "vue";
type VueApp = ReturnType<typeof createApp>;
import App from "./vue-vapor/App.vue";
import type { BenchApp, RowData } from "../data";
let instance: VueApp | undefined;
const api: Record<string, any> = {};
export const app: BenchApp = {
  name: "vue-vapor",
  version: "3.6.0-rc.13",
  mountA(container, data) { instance = createApp(App, { initial: data, api }); instance.mount(container); },
  unmountA() { instance!.unmount(); instance = undefined; },
  initB(container) { instance = createApp(App, { initial: [], api }); instance.mount(container); },
  createB(data) { api.rows.value = data; return nextTick(); },
  clearB() { api.rows.value = []; return nextTick(); },
  disposeB() { instance!.unmount(); instance = undefined; },
  updateEvery10th() { api.rows.value = api.rows.value.map((r: RowData, i: number) => (i % 10 === 0 ? { ...r, label: r.label + " !!!" } : r)); return nextTick(); },
  flush: () => nextTick(),
};

// ---- Scenario C: light rows (Row component with a shallowRef).
import LightApp from "./vue-vapor/LightApp.vue";
import { resetRefs } from "./vue-vapor/registry";
let lightApp: VueApp | undefined, lightRefs: { value: number }[] = [], lightN = 0;
app.mountC = (container, n) => {
  lightN = n; lightRefs = new Array(n);
  lightRefs = resetRefs();
  lightApp = createApp(LightApp, { ids: Array.from({ length: n }, (_, i) => i) });
  lightApp.mount(container);
};
app.updateC = (value) => { for (let i = 0; i < lightN; i += 10) lightRefs[i].value = value; return nextTick(); };
app.unmountC = () => { lightApp!.unmount(); lightApp = undefined; lightRefs = []; };
