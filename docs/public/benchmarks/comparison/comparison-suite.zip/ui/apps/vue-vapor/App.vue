<script setup vapor lang="ts">
import { shallowRef } from "vue";
import Row from "./Row.vue";
// Large-list idiom: shallowRef with immutable item updates (no deep proxies for 10k rows).
const props = defineProps<{ initial: { id: number; label: string }[]; api: Record<string, unknown> }>();
const rows = shallowRef(props.initial);
props.api.rows = rows;
const remove = (id: number) => { rows.value = rows.value.filter((r) => r.id !== id); };
</script>
<template>
  <table class="table table-hover table-striped test-data">
    <tbody>
      <Row v-for="item in rows" :key="item.id" :item="item" @remove="remove" />
    </tbody>
  </table>
</template>
