<script setup vapor lang="ts">
import LightRow from "./LightRow.vue";
defineProps<{ ids: number[] }>();
</script>
<template><table><tbody><LightRow v-for="id in ids" :key="id" :id="id" /></tbody></table></template>
