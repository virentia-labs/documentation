// Light rows register their counter here (a function prop does not reach a Vapor child in 3.6.0-rc.13).
export let refs: { value: number }[] = [];
export function resetRefs(): { value: number }[] { refs = []; return refs; }
export function register(id: number, value: { value: number }): void { refs[id] = value; }
