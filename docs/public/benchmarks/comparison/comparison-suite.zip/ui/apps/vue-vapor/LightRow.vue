<script setup vapor lang="ts">
import { shallowRef } from "vue";
import { register } from "./registry";
const props = defineProps<{ id: number }>();
const count = shallowRef(0);
register(props.id, count);
</script>
<template><tr><td>{{ id }}</td><td>{{ count }}</td></tr></template>
