// Idiomatic Vue 3.5: SFCs (<script setup>, production-compiled with inline templates), Row component per row.
import { createApp, nextTick, type App as VueApp } from "vue";
import App from "./vue/App.vue";
import type { BenchApp, RowData } from "../data";
let instance: VueApp | undefined;
const api: Record<string, any> = {};
export const app: BenchApp = {
  name: "vue",
  version: "3.5.44",
  mountA(container, data) { instance = createApp(App, { initial: data, api }); instance.mount(container); },
  unmountA() { instance!.unmount(); instance = undefined; },
  initB(container) { instance = createApp(App, { initial: [], api }); instance.mount(container); },
  createB(data) { api.rows.value = data; return nextTick(); },
  clearB() { api.rows.value = []; return nextTick(); },
  disposeB() { instance!.unmount(); instance = undefined; },
  updateEvery10th() { api.rows.value = api.rows.value.map((r: RowData, i: number) => (i % 10 === 0 ? { ...r, label: r.label + " !!!" } : r)); return nextTick(); },
  flush: () => nextTick(),
};

// ---- Scenario C: light rows (Row component with a shallowRef).
import LightApp from "./vue/LightApp.vue";
let lightApp: VueApp | undefined, lightRefs: { value: number }[] = [], lightN = 0;
app.mountC = (container, n) => {
  lightN = n; lightRefs = new Array(n);
  lightApp = createApp(LightApp, { ids: Array.from({ length: n }, (_, i) => i), reg: (id: number, r: { value: number }) => { lightRefs[id] = r; } });
  lightApp.mount(container);
};
app.updateC = (value) => { for (let i = 0; i < lightN; i += 10) lightRefs[i].value = value; return nextTick(); };
app.unmountC = () => { lightApp!.unmount(); lightApp = undefined; lightRefs = []; };
