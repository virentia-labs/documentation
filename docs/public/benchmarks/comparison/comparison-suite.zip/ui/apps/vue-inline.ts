// Vue 3.5 without a per-row component (js-framework-benchmark style).
import { createApp, nextTick, type App as VueApp } from "vue";
import App from "./vue/AppInline.vue";
import type { BenchApp, RowData } from "../data";
let instance: VueApp | undefined;
const api: Record<string, any> = {};
export const app: BenchApp = {
  name: "vue-inline",
  version: "3.5.44",
  mountA(container, data) { instance = createApp(App, { initial: data, api }); instance.mount(container); },
  unmountA() { instance!.unmount(); instance = undefined; },
  initB(container) { instance = createApp(App, { initial: [], api }); instance.mount(container); },
  createB(data) { api.rows.value = data.map((d) => ({ ...d, selected: false })); return nextTick(); },
  clearB() { api.rows.value = []; return nextTick(); },
  disposeB() { instance!.unmount(); instance = undefined; },
  updateEvery10th() { const rs = api.rows.value; for (let i = 0; i < rs.length; i += 10) rs[i].label += " !!!"; api.trigger(); return nextTick(); },
  flush: () => nextTick(),
};
