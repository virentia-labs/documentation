// Idiomatic React 19: state in App, memoized Row components, local per-row UI state.
import { memo, useCallback, useState } from "react";
import { createRoot, type Root } from "react-dom/client";
import { flushSync } from "react-dom";
import type { BenchApp, RowData } from "../data";

type Setter = (fn: RowData[] | ((rows: RowData[]) => RowData[])) => void;
const api: { setRows?: Setter } = {};

const Row = memo(function Row({ item, onRemove }: { item: RowData; onRemove: (id: number) => void }) {
  const [selected, setSelected] = useState(false);
  return (
    <tr className={selected ? "danger" : ""}>
      <td className="col-md-1">{item.id}</td>
      <td className="col-md-4"><a onClick={() => setSelected((s) => !s)}>{item.label}</a></td>
      <td className="col-md-1"><a onClick={() => onRemove(item.id)}><span className="glyphicon glyphicon-remove" aria-hidden="true" /></a></td>
      <td className="col-md-6" />
    </tr>
  );
});

function App({ initial }: { initial: RowData[] }) {
  const [rows, setRows] = useState(initial);
  api.setRows = setRows as Setter;
  const onRemove = useCallback((id: number) => setRows((rs) => rs.filter((r) => r.id !== id)), []);
  return (
    <table className="table table-hover table-striped test-data">
      <tbody>{rows.map((item) => <Row key={item.id} item={item} onRemove={onRemove} />)}</tbody>
    </table>
  );
}

let root: Root | undefined;
export const app: BenchApp = {
  name: "react",
  version: "19.3.1",
  mountA(container, data) {
    root = createRoot(container);
    flushSync(() => root!.render(<App initial={data} />));
  },
  unmountA() { root!.unmount(); root = undefined; },
  initB(container) { root = createRoot(container); flushSync(() => root!.render(<App initial={[]} />)); },
  createB(data) { flushSync(() => api.setRows!(data)); },
  clearB() { flushSync(() => api.setRows!([])); },
  disposeB() { root!.unmount(); root = undefined; },
  updateEvery10th() {
    flushSync(() => api.setRows!((rs) => rs.map((r, i) => (i % 10 === 0 ? { ...r, label: r.label + " !!!" } : r))));
  },
};

// ---- Scenario C: light rows with local state.
const lightSetters: ((v: number) => void)[] = [];
function LightRow({ id }: { id: number }) {
  const [count, set] = useState(0);
  lightSetters[id] = set;
  return <tr><td>{id}</td><td>{count}</td></tr>;
}
let lightRoot: Root | undefined, lightN = 0;
app.mountC = (container, n) => {
  lightN = n; lightRoot = createRoot(container);
  flushSync(() => lightRoot!.render(<table><tbody>{Array.from({ length: n }, (_, id) => <LightRow key={id} id={id} />)}</tbody></table>));
};
app.updateC = (value) => { flushSync(() => { for (let i = 0; i < lightN; i += 10) lightSetters[i](value); }); };
app.unmountC = () => { lightRoot!.unmount(); lightRoot = undefined; lightSetters.length = 0; };
