// Hand-written DOM baseline (no framework): template cloning, direct handlers, manual bookkeeping.
import type { BenchApp, RowData } from "../data";
const tpl = document.createElement("template");
tpl.innerHTML = '<tr><td class="col-md-1"></td><td class="col-md-4"><a></a></td><td class="col-md-1"><a><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td><td class="col-md-6"></td></tr>';
const rowTpl = tpl.content.firstChild as HTMLTableRowElement;
interface R { data: RowData; tr: HTMLTableRowElement; labelText: Text; selected: boolean }
let table: HTMLTableElement | undefined, tbody: HTMLTableSectionElement | undefined, rows: R[] = [], host: HTMLElement | undefined;
function makeRow(d: RowData): R {
  const tr = rowTpl.cloneNode(true) as HTMLTableRowElement;
  const td1 = tr.firstChild as HTMLElement, a1 = td1.nextSibling!.firstChild as HTMLElement, a2 = td1.nextSibling!.nextSibling!.firstChild as HTMLElement;
  td1.textContent = String(d.id);
  const labelText = document.createTextNode(d.label);
  a1.appendChild(labelText);
  const r: R = { data: d, tr, labelText, selected: false };
  a1.onclick = () => { r.selected = !r.selected; tr.className = r.selected ? "danger" : ""; };
  a2.onclick = () => { const i = rows.indexOf(r); rows.splice(i, 1); tr.remove(); };
  return r;
}
function createTable(container: HTMLElement) {
  host = container;
  table = document.createElement("table"); table.className = "table table-hover table-striped test-data";
  tbody = document.createElement("tbody"); table.appendChild(tbody); container.appendChild(table);
}
function fill(data: RowData[]) {
  const frag = document.createDocumentFragment();
  rows = data.map(makeRow);
  for (const r of rows) frag.appendChild(r.tr);
  tbody!.appendChild(frag);
}
export const app: BenchApp = {
  name: "vanilla", version: "DOM",
  mountA(container, data) { createTable(container); fill(data); },
  unmountA() { host!.textContent = ""; rows = []; table = tbody = undefined; },
  initB(container) { createTable(container); },
  createB(data) { fill(data); },
  clearB() { tbody!.textContent = ""; rows = []; },
  disposeB() { host!.textContent = ""; rows = []; },
  updateEvery10th() { for (let i = 0; i < rows.length; i += 10) { const r = rows[i]; r.data = { ...r.data, label: r.data.label + " !!!" }; r.labelText.data = r.data.label; } },
};

// ---- Scenario C: light rows.
let lightHost: HTMLElement | undefined, lightTexts: Text[] = [];
app.mountC = (container, n) => {
  lightHost = container;
  const table = document.createElement("table"), tbody = document.createElement("tbody");
  lightTexts = new Array(n);
  for (let i = 0; i < n; i++) {
    const tr = document.createElement("tr"), a = document.createElement("td"), b = document.createElement("td");
    a.textContent = String(i); const t = document.createTextNode("0"); b.appendChild(t); lightTexts[i] = t;
    tr.append(a, b); tbody.appendChild(tr);
  }
  table.appendChild(tbody); container.appendChild(table);
};
app.updateC = (value) => { for (let i = 0; i < lightTexts.length; i += 10) lightTexts[i].data = String(value); };
app.unmountC = () => { lightHost!.textContent = ""; lightTexts = []; };
