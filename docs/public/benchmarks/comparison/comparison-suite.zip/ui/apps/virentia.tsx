/** @jsxImportSource @virentia/ui */
// Idiomatic Virentia UI: rows are components bound to staticModel instances.
import { children, f, inverse, staticModel } from "@virentia/core/models";
import { action, component, computed, For, render, scope, scoped } from "@virentia/ui";
import type { BenchApp, RowData } from "../data";

// ---- Scenario A: board model owns rows (children.many), created from props on mount.
const RowA = staticModel({
  name: "BenchRowA",
  data: { label: f.string(""), selected: f.boolean(false), board: inverse(() => BoardA.rows) },
  setup(self) {
    const cls = computed(() => (self.selected.value ? "danger" : ""));
    const select = action(() => { self.selected.value = !self.selected.value; });
    const remove = action(() => {
      const rel = self.board as { value: { rows: { remove(id: string): void | Promise<void> } } | null };
      return rel.value?.rows.remove(self.id);
    });
    return { cls, select, remove };
  },
});
const BoardA = staticModel({
  name: "BenchBoardA",
  data: { rows: children.many(RowA) },
  setup(self) {
    const updateEvery10th = action(() => {
      const items = self.rows.items;
      for (let i = 0; i < items.length; i += 10) items[i].label.value += " !!!";
    });
    return { updateEvery10th };
  },
});
const RowViewA = component({
  model: RowA,
  view: (_p, self) => (
    <tr class={self.model.cls}>
      <td class="col-md-1">{self.id}</td>
      <td class="col-md-4"><a onClick={self.model.select}>{self.model.label}</a></td>
      <td class="col-md-1"><a onClick={self.model.remove}><span class="glyphicon glyphicon-remove" aria-hidden="true" /></a></td>
      <td class="col-md-6" />
    </tr>
  ),
});
let boardA: any;
const AppA = component({
  model: BoardA,
  view: (_p, self) => {
    boardA = self.model;
    return (
      <table class="table table-hover table-striped test-data">
        <tbody><For each={self.model.rows} view={RowViewA} /></tbody>
      </table>
    );
  },
});

// ---- Scenario B: rows live in the model's scope collection; For renders the collection.
const RowB = staticModel({
  name: "BenchRowB",
  data: { label: f.string(""), selected: f.boolean(false) },
  setup(self) {
    const cls = computed(() => (self.selected.value ? "danger" : ""));
    const select = action(() => { self.selected.value = !self.selected.value; });
    const remove = action(() => RowB.instances.remove(self.id));
    return { cls, select, remove };
  },
});
const RowViewB = component({
  model: RowB,
  view: (_p, self) => (
    <tr class={self.model.cls}>
      <td class="col-md-1">{self.id}</td>
      <td class="col-md-4"><a onClick={self.model.select}>{self.model.label}</a></td>
      <td class="col-md-1"><a onClick={self.model.remove}><span class="glyphicon glyphicon-remove" aria-hidden="true" /></a></td>
      <td class="col-md-6" />
    </tr>
  ),
});

let appScope: ReturnType<typeof scope> | undefined;
let detach: (() => Promise<void>) | undefined;
let mode: "A" | "B" | undefined;
const toDto = (data: RowData[]) => data.map((d) => ({ id: String(d.id), label: d.label }));

export const app: BenchApp = {
  name: "virentia",
  version: "working tree (fc3378e + uncommitted)",
  mountA(container, data) {
    mode = "A";
    appScope = scope();
    detach = render(() => <AppA rows={toDto(data)} />, container, { scope: appScope }) as any;
  },
  async unmountA() { await detach!(); detach = undefined; boardA = undefined; },
  initB(container) {
    mode = "B";
    appScope = scope();
    detach = render(() => (
      <table class="table table-hover table-striped test-data">
        <tbody><For each={RowB} view={RowViewB} /></tbody>
      </table>
    ), container, { scope: appScope }) as any;
  },
  createB(data) { scoped(appScope!, () => { RowB.create(toDto(data)); }); },
  clearB() { return scoped(appScope!, () => RowB.instances.remove()) as any; },
  async disposeB() { await this.clearB(); await detach!(); detach = undefined; },
  updateEvery10th() {
    if (mode === "A") scoped(appScope!, () => boardA.updateEvery10th());
    else scoped(appScope!, () => { const items = RowB.instances.items; for (let i = 0; i < items.length; i += 10) items[i].label.value += " !!!"; });
  },
};

// ---- Scenario C: light rows exactly like the repo's own benchmarks/ui.harness.ts (component + staticModel per row).
const LightModel = staticModel({ data: { count: f.number(0) } });
let lightValues: any[] = [];
const LightRow = component({
  model: LightModel,
  view(_p, self) {
    lightValues[Number(self.id)] = self.model.count;
    return <tr><td>{self.id}</td><td>{self.model.count}</td></tr>;
  },
});
let lightDetach: (() => Promise<void>) | undefined, lightScope: ReturnType<typeof scope> | undefined, lightN = 0;
app.mountC = (container, n) => {
  lightN = n; lightValues = new Array(n); lightScope = scope();
  lightDetach = render(() => <table><tbody>{Array.from({ length: n }, (_, id) => <LightRow id={String(id)} key={id} />)}</tbody></table>, container, { scope: lightScope }) as any;
};
app.updateC = (value) => { scoped(lightScope!, () => { for (let i = 0; i < lightN; i += 10) lightValues[i].value = value; }); };
app.unmountC = async () => { await lightDetach!(); lightDetach = undefined; lightValues = []; };
