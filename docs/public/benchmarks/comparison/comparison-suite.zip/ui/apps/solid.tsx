// Idiomatic Solid 1.9 (compiled JSX): per-row label signal, Row component, <For>.
import { createSignal, For, type Accessor, type Setter } from "solid-js";
import { render } from "solid-js/web";
import type { BenchApp, RowData } from "../data";

interface Item { id: number; label: Accessor<string>; setLabel: Setter<string> }
const toItems = (data: RowData[]): Item[] => data.map((d) => { const [label, setLabel] = createSignal(d.label); return { id: d.id, label, setLabel }; });

let setRowsRef: Setter<Item[]> | undefined;
let rowsRef: Accessor<Item[]> | undefined;

function Row(props: { item: Item; onRemove: (id: number) => void }) {
  const [selected, setSelected] = createSignal(false);
  return (
    <tr class={selected() ? "danger" : ""}>
      <td class="col-md-1">{props.item.id}</td>
      <td class="col-md-4"><a onClick={() => setSelected(!selected())}>{props.item.label()}</a></td>
      <td class="col-md-1"><a onClick={() => props.onRemove(props.item.id)}><span class="glyphicon glyphicon-remove" aria-hidden="true" /></a></td>
      <td class="col-md-6" />
    </tr>
  );
}
function App(props: { initial: Item[] }) {
  const [rows, setRows] = createSignal(props.initial);
  setRowsRef = setRows; rowsRef = rows;
  const remove = (id: number) => setRows((rs) => rs.filter((r) => r.id !== id));
  return (
    <table class="table table-hover table-striped test-data">
      <tbody><For each={rows()}>{(item) => <Row item={item} onRemove={remove} />}</For></tbody>
    </table>
  );
}

let dispose: (() => void) | undefined;
export const app: BenchApp = {
  name: "solid",
  version: "1.9.17",
  mountA(container, data) { dispose = render(() => <App initial={toItems(data)} />, container); },
  unmountA() { dispose!(); dispose = undefined; },
  initB(container) { dispose = render(() => <App initial={[]} />, container); },
  createB(data) { setRowsRef!(toItems(data)); },
  clearB() { setRowsRef!([]); },
  disposeB() { dispose!(); dispose = undefined; },
  updateEvery10th() { const rs = rowsRef!(); for (let i = 0; i < rs.length; i += 10) rs[i].setLabel((l) => l + " !!!"); },
};

// ---- Scenario C: light rows with a per-row signal.
const lightSetters: Setter<number>[] = [];
function LightRow(props: { id: number }) {
  const [count, set] = createSignal(0);
  lightSetters[props.id] = set;
  return <tr><td>{props.id}</td><td>{count()}</td></tr>;
}
let lightDispose: (() => void) | undefined, lightN = 0;
app.mountC = (container, n) => {
  lightN = n;
  const ids = Array.from({ length: n }, (_, i) => i);
  lightDispose = render(() => <table><tbody><For each={ids}>{(id) => <LightRow id={id} />}</For></tbody></table>, container);
};
app.updateC = (value) => { for (let i = 0; i < lightN; i += 10) lightSetters[i](value); };
app.unmountC = () => { lightDispose!(); lightDispose = undefined; lightSetters.length = 0; };
