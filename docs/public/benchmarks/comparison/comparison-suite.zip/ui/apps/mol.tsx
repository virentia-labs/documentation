// $mol via mol_jsx_lib: $mol_jsx_view components + $mol_wire atoms ($mol_mem).
// Note: $mol_jsx requires unique local ids for every element of a view (it reuses DOM by global id).
import $ from "mol_jsx_lib";
import type { BenchApp, RowData } from "../data";
const { $mol_jsx_view, $mol_mem, $mol_object2, $mol_wire_fiber, $mol_jsx_attach } = $ as any;
const $mol_jsx = ($ as any).$mol_jsx;
const mem = (proto: object, name: string) => {
  const d = Object.getOwnPropertyDescriptor(proto, name)!;
  const r = $mol_mem(proto, name, d);
  if (r) Object.defineProperty(proto, name, r);
};

class Item extends $mol_object2 {
  id = 0;
  label(next?: string): string { return next ?? ""; }
}
mem(Item.prototype, "label");
const toItems = (data: RowData[]) => data.map((d) => { const it = new Item(); it.id = d.id; it.label(d.label); return it; });

class Row extends $mol_jsx_view {
  item!: Item;
  remove!: (id: number) => void;
  selected(next?: boolean): boolean { return next ?? false; }
  render() {
    return (
      <tr class={this.selected() ? "danger" : ""}>
        <td id="id" class="col-md-1">{String(this.item.id)}</td>
        <td id="label" class="col-md-4"><a id="select" onclick={() => this.selected(!this.selected())}>{this.item.label()}</a></td>
        <td id="actions" class="col-md-1"><a id="remove" onclick={() => this.remove(this.item.id)}><span id="icon" class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>
        <td id="pad" class="col-md-6"></td>
      </tr>
    );
  }
}
mem(Row.prototype, "selected");

class Store extends $mol_object2 {
  rows(next?: Item[]): Item[] { return next ?? []; }
}
mem(Store.prototype, "rows");
class App extends $mol_jsx_view {
  store!: Store;
  remove = (id: number) => { this.store.rows(this.store.rows().filter((r) => r.id !== id)); };
  render() {
    return (
      <table class="table table-hover table-striped test-data">
        <tbody id="body">{this.store.rows().map((item) => <Row id={"row" + item.id} item={item} remove={this.remove} />)}</tbody>
      </table>
    );
  }
}

let view: any, node: HTMLElement | undefined, host: HTMLElement | undefined;
let counter = 0;
// Root render: attach to the document so $mol_jsx can reuse elements by id on re-render.
let store: Store | undefined;
function mountApp(container: HTMLElement, items: Item[]) {
  host = container;
  const id = "app" + ++counter;
  store = new Store();
  store.rows(items);
  node = $mol_jsx_attach(document, () => $mol_jsx(App, { id, store }));
  view = App.of(node);
  container.appendChild(node!);
}
function rerender() { view.valueOf(); $mol_wire_fiber.sync(); }
function destroy() {
  node!.remove();
  view.destructor();
  $mol_wire_fiber.sync();
  view = node = store = undefined;
}
export const app: BenchApp = {
  name: "mol",
  version: "mol_jsx_lib 0.0.1682 / mol_wire 1.0.1824",
  mountA(container, data) { mountApp(container, toItems(data)); },
  unmountA() { destroy(); },
  initB(container) { mountApp(container, []); },
  createB(data) { store!.rows(toItems(data)); rerender(); },
  clearB() { store!.rows([]); rerender(); },
  disposeB() { destroy(); },
  updateEvery10th() { const rs = store!.rows(); for (let i = 0; i < rs.length; i += 10) rs[i].label(rs[i].label() + " !!!"); rerender(); },
  flush() { rerender(); },
};

// ---- Scenario C: light rows ($mol_jsx_view per row with a $mol_mem count).
class LightRow extends $mol_jsx_view {
  idx = 0;
  count(next?: number): number { return next ?? 0; }
  render() { return <tr><td id="i">{String(this.idx)}</td><td id="c">{String(this.count())}</td></tr>; }
}
mem(LightRow.prototype, "count");
class LightStore extends $mol_object2 { ids(next?: number[]): number[] { return next ?? []; } }
mem(LightStore.prototype, "ids");
class LightApp extends $mol_jsx_view {
  store!: LightStore;
  render() { return <table><tbody id="body">{this.store.ids().map((i) => <LightRow id={"r" + i} idx={i} />)}</tbody></table>; }
}
let lightNode: HTMLElement | undefined, lightView: any, lightN = 0;
app.mountC = (container, n) => {
  lightN = n;
  const store = new LightStore(); store.ids(Array.from({ length: n }, (_, i) => i));
  lightNode = $mol_jsx_attach(document, () => $mol_jsx(LightApp, { id: "light" + ++counter, store }));
  lightView = LightApp.of(lightNode); container.appendChild(lightNode!);
};
app.updateC = (value) => {
  const body = lightNode!.querySelector("tbody")!;
  for (let i = 0; i < lightN; i += 10) LightRow.of(body.children[i] as Element).count(value);
  lightView.valueOf(); $mol_wire_fiber.sync();
};
app.unmountC = () => { lightNode!.remove(); lightView.destructor(); $mol_wire_fiber.sync(); lightNode = lightView = undefined; };
