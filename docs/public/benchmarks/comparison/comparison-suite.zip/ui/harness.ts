// Browser-side harness shared by all frameworks. Bundled together with one app module.
import { buildData, resetSeed, type BenchApp, type RowData } from "./data";
declare const gc: () => void;

let app: BenchApp;
const now = () => performance.now();
const frame = () => new Promise<void>((r) => requestAnimationFrame(() => r()));
const macrotask = () => new Promise<void>((r) => setTimeout(r, 0));
async function settle() { await frame(); await macrotask(); if (!(globalThis as any).benchNoGC) gc(); await frame(); await macrotask(); }
const heap = () => (performance as any).memory.usedJSHeapSize as number;
const assert = (c: unknown, m: string) => { if (!c) throw new Error(`[${app.name}] ${m}`); };
const maybe = async (r: unknown) => { if (r && typeof (r as any).then === "function") await r; };
const forceLayout = (el: HTMLElement) => el.getBoundingClientRect().height + document.body.offsetHeight;

function rows(container: HTMLElement) { return container.querySelectorAll("tbody > tr"); }
function checkRows(container: HTMLElement, data: RowData[], what: string) {
  const trs = rows(container);
  assert(trs.length === data.length, `${what}: expected ${data.length} rows, got ${trs.length}`);
  for (const i of [0, 1, Math.floor(data.length / 2), data.length - 1]) {
    if (i < 0 || i >= data.length) continue;
    const tr = trs[i] as HTMLTableRowElement;
    assert(tr.cells.length === 4, `${what}: row ${i} has ${tr.cells.length} cells`);
    assert(tr.cells[0].textContent === String(data[i].id), `${what}: row ${i} id '${tr.cells[0].textContent}' != ${data[i].id}`);
    assert(tr.cells[1].textContent === data[i].label, `${what}: row ${i} label '${tr.cells[1].textContent}' != '${data[i].label}'`);
    assert(!tr.classList.contains("danger"), `${what}: row ${i} class '${tr.className}'`);
    assert(tr.querySelector("span.glyphicon.glyphicon-remove") !== null, `${what}: row ${i} lacks remove icon`);
  }
}
async function click(el: Element) {
  el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  await maybe(app.flush?.());
  await macrotask(); await frame();
}

async function verifyScenario(container: HTMLElement, scenario: "A" | "B") {
  resetSeed();
  const data = buildData(1000);
  if (scenario === "A") await maybe(app.mountA(container, data));
  else { await maybe(app.initB(container)); assert(rows(container).length === 0, "B init not empty"); await maybe(app.createB(data)); }
  await maybe(app.flush?.());
  checkRows(container, data, `${scenario}/mount`);
  // toggle select on row 3
  let tr = rows(container)[2] as HTMLTableRowElement;
  await click(tr.cells[1].querySelector("a")!);
  assert((rows(container)[2] as HTMLElement).classList.contains("danger"), `${scenario}: select did not set class (got '${(rows(container)[2] as HTMLElement).className}')`);
  assert(!(rows(container)[3] as HTMLElement).classList.contains("danger"), `${scenario}: select leaked to row 4`);
  await click((rows(container)[2] as HTMLTableRowElement).cells[1].querySelector("a")!);
  assert(!(rows(container)[2] as HTMLElement).classList.contains("danger"), `${scenario}: second click did not clear class`);
  // update every 10th (snapshot labels first: some frameworks mutate the source objects in place)
  const labels = data.map((d) => d.label);
  const before = rows(container)[0];
  await maybe(app.updateEvery10th()); await maybe(app.flush?.()); await macrotask();
  const trs = rows(container);
  for (let i = 0; i < 30; i++) {
    const expect = labels[i] + (i % 10 === 0 ? " !!!" : "");
    assert((trs[i] as HTMLTableRowElement).cells[1].textContent === expect, `${scenario}: update row ${i} '${(trs[i] as HTMLTableRowElement).cells[1].textContent}' != '${expect}'`);
  }
  assert(trs[0] === before, `${scenario}: update replaced the row element instead of patching it`);
  // remove row 5
  const removedId = data[4].id;
  const keep = rows(container)[5];
  await click((rows(container)[4] as HTMLTableRowElement).cells[2].querySelector("a")!);
  assert(rows(container).length === 999, `${scenario}: remove -> ${rows(container).length} rows`);
  assert((rows(container)[4] as HTMLTableRowElement).cells[0].textContent === String(data[5].id), `${scenario}: wrong row removed (expected ${removedId} gone)`);
  assert(rows(container)[4] === keep, `${scenario}: remove recreated the following row`);
  if (scenario === "A") await maybe(app.unmountA());
  else { await maybe(app.clearB()); await maybe(app.flush?.()); assert(rows(container).length === 0, "B clear left rows"); await maybe(app.disposeB()); }
  assert(container.childNodes.length === 0 || container.innerHTML.trim() === "", `${scenario}: container not empty after unmount: ${container.innerHTML.slice(0, 80)}`);
  return true;
}

async function verify() {
  const container = document.createElement("div");
  document.getElementById("main")!.append(container);
  const out: Record<string, unknown> = {};
  for (const s of ["A", "B"] as const) {
    try { out[s] = await verifyScenario(container, s); } catch (e) { out[s] = String((e as Error)?.message) + " :: " + String((e as Error)?.stack || e).slice(0, 300); }
    container.replaceChildren();
  }
  container.remove();
  return out;
}

interface RunConfig { scenario: "A" | "B" | "C"; n: number; warmup: number; rounds: number }
function checkLight(container: HTMLElement, n: number, value: number, what: string) {
  const trs = rows(container);
  assert(trs.length === n, `${what}: expected ${n} rows, got ${trs.length}`);
  for (const i of [0, 1, 10, n - 1]) {
    const tr = trs[i] as HTMLTableRowElement;
    assert(tr.cells[0].textContent === String(i), `${what}: row ${i} id '${tr.cells[0].textContent}'`);
    const exp = i % 10 === 0 ? value : 0;
    assert(tr.cells[1].textContent === String(exp), `${what}: row ${i} count '${tr.cells[1].textContent}' != ${exp}`);
  }
}
async function runLight(cfg: RunConfig) {
  const container = document.createElement("div");
  document.getElementById("main")!.append(container);
  const samples: Record<string, number>[] = [];
  for (let round = 0; round < cfg.warmup + cfg.rounds; round++) {
    await settle();
    const heap0 = heap();
    const t0 = now();
    await maybe(app.mountC!(container, cfg.n));
    const t1 = now();
    forceLayout(container);
    const t2 = now();
    checkLight(container, cfg.n, 0, "C/mount");
    await settle();
    const heap1 = heap();
    await maybe(app.updateC!(1));            // untimed warm update
    await settle();
    const t3 = now();
    await maybe(app.updateC!(2));
    const t4 = now();
    checkLight(container, cfg.n, 2, "C/update");
    await settle();
    const t5 = now();
    await maybe(app.unmountC!());
    const t6 = now();
    forceLayout(container);
    const t7 = now();
    assert(rows(container).length === 0, "C: rows left after unmount");
    await settle();
    const heap2 = heap();
    samples.push({ round, warm: round >= cfg.warmup ? 1 : 0, mount: t1 - t0, mountLayout: t2 - t0, update: t4 - t3, unmount: t6 - t5, unmountLayout: t7 - t5,
      heapMountedMB: (heap1 - heap0) / 1048576, heapLeakMB: (heap2 - heap0) / 1048576 });
  }
  container.remove();
  return { name: app.name, version: app.version, ...cfg, samples };
}
async function run(cfg: RunConfig) {
  if (cfg.scenario === "C") return runLight(cfg);
  const container = document.createElement("div");
  document.getElementById("main")!.append(container);
  const samples: Record<string, number>[] = [];
  resetSeed();
  if (cfg.scenario === "B") { await maybe(app.initB(container)); await maybe(app.flush?.()); }
  for (let round = 0; round < cfg.warmup + cfg.rounds; round++) {
    const data = buildData(cfg.n);
    await settle();
    const heap0 = heap();
    const t0 = now();
    if (cfg.scenario === "A") await maybe(app.mountA(container, data));
    else await maybe(app.createB(data));
    const t1 = now();
    forceLayout(container);
    const t2 = now();
    checkRows(container, data, `run/${cfg.scenario}/mount`);
    await settle();
    const heap1 = heap();
    const t3 = now();
    if (cfg.scenario === "A") await maybe(app.unmountA());
    else await maybe(app.clearB());
    const t4 = now();
    forceLayout(container);
    const t5 = now();
    assert(rows(container).length === 0, `run/${cfg.scenario}: rows left after unmount/clear`);
    await settle();
    const heap2 = heap();
    samples.push({ round, warm: round >= cfg.warmup ? 1 : 0, mount: t1 - t0, mountLayout: t2 - t0, unmount: t4 - t3, unmountLayout: t5 - t3,
      heapMountedMB: (heap1 - heap0) / 1048576, heapLeakMB: (heap2 - heap0) / 1048576 });
  }
  if (cfg.scenario === "B") await maybe(app.disposeB());
  container.remove();
  return { name: app.name, version: app.version, ...cfg, samples };
}

// Diagnostics: DOM node census after mounting 1000 rows (elements, text, comments, attributes with ids).
async function count(container: HTMLElement, scenario: "A" | "B" | "C") {
  resetSeed();
  const data = buildData(1000);
  if (scenario === "A") await maybe(app.mountA(container, data));
  else if (scenario === "B") { await maybe(app.initB(container)); await maybe(app.createB(data)); }
  else await maybe(app.mountC!(container, 1000));
  let el = 0, text = 0, comment = 0, withId = 0, listeners = 0;
  const walk = (n: Node) => { for (let c = n.firstChild; c; c = c.nextSibling) { if (c.nodeType === 1) { el++; if ((c as Element).id) withId++; walk(c); } else if (c.nodeType === 3) text++; else if (c.nodeType === 8) comment++; } };
  walk(container);
  const tbody = container.querySelector("tbody")!;
  const res = { elements: el, text, comments: comment, withId, tbodyChildNodes: tbody.childNodes.length };
  if (scenario === "A") await maybe(app.unmountA()); else if (scenario === "B") await maybe(app.disposeB()); else await maybe(app.unmountC!());
  return res;
}
export function install(a: BenchApp) {
  app = a;
  Object.assign(globalThis, { benchVerify: verify, benchRun: run, benchCount: count, benchInfo: { name: a.name, version: a.version }, benchApp: a, benchBuildData: buildData, benchResetSeed: resetSeed, benchSettle: settle, benchReady: true });
}
