# Virentia comparison benchmarks

UI: Virentia UI vs React, Vue, Solid, $mol (`mol_jsx_lib`) and vanilla DOM in Chromium (Playwright).
Core: Virentia core and models vs MobX, Effector, Reatom and Redux in Node.
Everything is bundled with esbuild (minified, `NODE_ENV=production`); Virentia is aliased to its sources.

```sh
npm ci
npx playwright install chromium            # or set CHROME_PATH to an installed Chrome/Chromium
export VIRENTIA_PACKAGES=/absolute/path/to/virentia/packages
mkdir -p results

# UI: one fresh browser context per (framework, scenario, size), forced GC between operations
VIRENTIA_TEMPLATES=1 node ui/build.mjs     # Virentia JSX compiled into templates, as @virentia/ui/vite does
node ui/run.mjs fw=virentia,react,vue,solid,mol,vanilla scenario=A,B,C n=1000,10000 out=results/ui.json
node ui/run.mjs fw=virentia,react,vue,solid,mol,vanilla scenario=A,B,C n=1000,10000 nogc=1 out=results/ui-nogc.json

# Core: one fresh Node process per (library, scenario, size, repetition)
node core/build.mjs
BENCH_NOGC=1 node core/run.mjs p=3 out=results/core.jsonl
```

UI scenarios:
* **A** — mount and unmount a root with N js-framework-benchmark rows; every row is a component with its own state
  (selected class, reactive label) and two handlers. Mount includes creating the rows' state from the data array.
* **B** — create N rows in an already mounted list, then clear them (js-framework-benchmark "create rows" / "clear rows").
* **C** — light rows `<tr><td>id</td><td>{count}</td></tr>` with state per row, plus updating every 10th row.

Every framework first passes a functional check: a click toggles the class, an update patches rows in place,
remove deletes the right row, unmount leaves no DOM. `mount`/`unmount` is synchronous JS until the DOM is complete
(returned promises are awaited). 5 warmup + 20 measured rounds at 1,000 rows, 3 + 10 at 10,000.

Core scenarios go through a thin adapter (`signal`, `computed`, `observe`, `write`, `batch`, see `core/adapter.ts`);
`events` and `todos*` are written idiomatically per library in `core/apps`. Every round is validated: observer call counts
and values. 5 warmup + 10 measured rounds at the smaller size, 2 + 4 at the larger one, 3 processes per cell.
