import { action, computed, configure, makeObservable, observable, reaction, runInAction, type IObservableValue } from "mobx";
import { register, registerTodos } from "../idiomatic";
configure({ enforceActions: "never" });
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;

register("events", "mobx", (n) => {
  let counters: IObservableValue<number>[], tick: (a: number) => void, offs: (() => void)[] = [], calls = 0;
  return { prime: true,
    build() {
      counters = Array.from({ length: M }, () => observable.box(0));
      tick = action((a: number) => { for (const c of counters) c.set(c.get() + a); });
      for (const c of counters) offs.push(reaction(() => c.get(), () => { calls++; }));
    },
    run() { calls = 0; for (let i = 0; i < n; i++) tick(1); },
    check() { assert(calls === n * M && counters[3].get() === 2 * n, `events ${calls} ${counters[3].get()}`); },
    teardown() { for (const o of offs) o(); offs = []; } };
});

class Todo {
  done = false;
  constructor(public id: string, public title: string) {
    makeObservable(this, { title: observable, done: observable, toggle: action });
  }
  toggle() { this.done = !this.done; }
}
registerTodos("mobx", (n) => {
  const list = observable.array<Todo>([], { deep: false });
  const doneCount = computed(() => { let c = 0; for (const t of list) if (t.done) c++; return c; });
  let offs: (() => void)[] = [], rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i }));
  return {
    create() {
      runInAction(() => list.replace(data.map((d) => new Todo(d.id, d.title))));
      for (const t of list) offs.push(reaction(() => t.done, () => { rowCalls++; }));
      offs.push(reaction(() => doneCount.get(), (v) => { lastCount = v; countCalls++; }, { fireImmediately: true }));
    },
    toggleTenth() { for (let i = 0; i < n; i += 10) list[i].toggle(); },
    toggleAll() { runInAction(() => { for (const t of list) t.toggle(); }); },
    remove() { for (const o of offs) o(); offs = []; runInAction(() => list.clear()); },
    reset() { rowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls, countCalls, lastCount, size: list.length }; },
  };
});
