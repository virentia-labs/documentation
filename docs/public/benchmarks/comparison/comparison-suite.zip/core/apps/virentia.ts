import { computed, event, reaction, scope, scoped, store, type Scope, type StoreWritable } from "@virentia/core";
import { f, staticModel } from "@virentia/core/models";
import { register, registerTodos, type TodosImpl } from "../idiomatic";
declare const OBSERVE_MODE: string;
declare const TODO_INDEX: boolean;
let setupRowCalls = 0;
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;

// ---------------- events: one event updates 10 counters (one transaction); n dispatches.
function eventsCase(inScope: boolean) {
  return (n: number) => {
    let sc: Scope, counters: StoreWritable<number>[], tick: ReturnType<typeof event<number>>, offs: (() => void)[] = [];
    let calls = 0;
    return {
      prime: true,
      build() {
        sc = scope();
        counters = Array.from({ length: M }, () => store(0));
        tick = event<number>();
        reaction({ on: tick, run(a) { for (const c of counters) c.value += a; } });
        for (const c of counters) {
          scoped(sc, () => c.value);
          offs.push(c.subscribe(() => { calls++; }));
        }
      },
      run(round: number) {
        calls = 0;
        if (inScope) scoped(sc, () => { for (let i = 0; i < n; i++) tick(1); });
        else for (let i = 0; i < n; i++) scoped(sc, () => tick(1));
      },
      check(round: number) {
        assert(calls === n * M, `events: calls ${calls}`);
        assert(scoped(sc, () => counters[3].value) === 2 * n, `events: value ${scoped(sc, () => counters[3].value)}`);
      },
      teardown() { for (const o of offs) o(); offs = []; },
    };
  };
}
register("events", "virentia", eventsCase(false));
register("eventsInScope", "virentia", eventsCase(true));

// ---------------- todos: N entities with per-entity observer + aggregate (done count) observer.
const Todo = staticModel({
  name: "BenchTodo",
  data: { title: f.string(""), done: TODO_INDEX ? f.boolean(false).indexed() : f.boolean(false) },
  setup(self) {
    const toggle = event<void>();
    reaction({ on: toggle, run() { self.done.value = !self.done.value; } });
    // "setup" mode: the per-row observer is a model reaction (runs in the instance scope, like a UI view binding).
    if (OBSERVE_MODE === "setup") reaction({ on: self.done, run() { setupRowCalls++; } });
    return { toggle };
  },
});
const toggleAll = event<void>();
reaction({ on: toggleAll, run() { for (const t of Todo.instances) t.done.value = !t.done.value; } });
// Indexed query (Virentia's own fast path) or a plain scan like the other libraries do.
const doneCount = TODO_INDEX
  ? computed(() => Todo.where(Todo.done.eq(true)).count)
  : computed(() => { let c = 0; for (const t of Todo.instances) if (t.done.value) c++; return c; });

function todos(n: number) {
  let sc: Scope = scope();
  let items: any[] = [];
  let offs: (() => void)[] = [];
  let rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i }));
  const observeRow = (t: any) => {
    if (OBSERVE_MODE === "auto") { const r = reaction({ scope: sc, run: () => { t.done.value; rowCalls++; } }); return () => r.stop(); }
    t.done.value; // materialize in the app scope (caller wraps the loop in one scoped())
    return t.done.subscribe(() => { rowCalls++; });
  };
  return {
    create() {
      sc = scope();
      items = scoped(sc, () => Todo.create(data));
      if (OBSERVE_MODE !== "setup") scoped(sc, () => { for (const t of items) offs.push(observeRow(t)); });
      if (OBSERVE_MODE === "auto") { const r = reaction({ scope: sc, run: () => { lastCount = doneCount.value; countCalls++; } }); offs.push(() => r.stop()); }
      else { lastCount = scoped(sc, () => doneCount.value); offs.push(doneCount.subscribe((v) => { lastCount = v; countCalls++; })); }
    },
    toggleTenth() { for (let i = 0; i < n; i += 10) scoped(sc, () => items[i].toggle()); },
    toggleAll() { scoped(sc, () => toggleAll()); },
    remove() { for (const o of offs) o(); offs = []; return scoped(sc, () => Todo.instances.remove()) as unknown as Promise<void> | void; },
    reset() { rowCalls = 0; setupRowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls: OBSERVE_MODE === "setup" ? setupRowCalls : rowCalls, countCalls, lastCount, size: scoped(sc, () => Todo.instances.count) }; },
  };
}
registerTodos("virentia", todos as (n: number) => TodosImpl);

