import { createEvent, createStore, createWatch, fork, scopeBind, clearNode, type Scope, type Store } from "effector";
import { register, registerTodos } from "../idiomatic";
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;
register("events", "effector-scope", (n) => {
  let scope: Scope, counters: Store<number>[], tick: (a: number) => void, offs: (() => void)[] = [], calls = 0, nodes: any[] = [];
  return { prime: true,
    build() {
      scope = fork();
      const ev = createEvent<number>(); nodes.push(ev);
      counters = Array.from({ length: M }, () => { const s = createStore(0).on(ev, (x, a) => x + a); nodes.push(s); return s; });
      tick = scopeBind(ev, { scope });
      for (const c of counters) { const u = createWatch({ unit: c, fn: () => { calls++; }, scope }); offs.push(() => u()); }
    },
    run() { calls = 0; for (let i = 0; i < n; i++) tick(1); },
    check() { assert(calls === n * M && scope.getState(counters[3]) === 2 * n, `events ${calls} ${scope.getState(counters[3])}`); },
    teardown() { for (const o of offs) o(); offs = []; for (const x of nodes) clearNode(x); nodes = []; } };
});
interface Todo { id: string; title: string; done: boolean }
interface S { ids: string[]; byId: Record<string, Todo> }
registerTodos("effector-scope", (n) => {
  const added = createEvent<Todo[]>(), toggled = createEvent<string>(), toggledAll = createEvent<void>(), cleared = createEvent<void>();
  const $todos = createStore<S>({ ids: [], byId: {} })
    .on(added, (s, list) => { const byId = { ...s.byId }; const ids = s.ids.slice(); for (const t of list) { byId[t.id] = t; ids.push(t.id); } return { ids, byId }; })
    .on(toggled, (s, id) => ({ ids: s.ids, byId: { ...s.byId, [id]: { ...s.byId[id], done: !s.byId[id].done } } }))
    .on(toggledAll, (s) => { const byId: Record<string, Todo> = {}; for (const id of s.ids) { const t = s.byId[id]; byId[id] = { ...t, done: !t.done }; } return { ids: s.ids, byId }; })
    .on(cleared, () => ({ ids: [], byId: {} }));
  const $doneCount = $todos.map((s) => { let c = 0; for (const id of s.ids) if (s.byId[id].done) c++; return c; });
  let scope: Scope = fork(), offs: (() => void)[] = [], rows: any[] = [], rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i, done: false }));
  let bAdded: (l: Todo[]) => void, bToggled: (id: string) => void, bAll: () => void, bCleared: () => void;
  return {
    create() {
      scope = fork();
      bAdded = scopeBind(added, { scope }); bToggled = scopeBind(toggled, { scope }); bAll = scopeBind(toggledAll, { scope }); bCleared = scopeBind(cleared, { scope });
      bAdded(data.map((d) => ({ ...d })));
      for (const id of scope.getState($todos).ids) {
        const $row = $todos.map((s) => s.byId[id]?.done ?? null); rows.push($row);
        const u = createWatch({ unit: $row, fn: () => { rowCalls++; }, scope }); offs.push(() => u());
      }
      lastCount = scope.getState($doneCount);
      const u = createWatch({ unit: $doneCount, fn: (v) => { lastCount = v; countCalls++; }, scope }); offs.push(() => u());
    },
    toggleTenth() { for (let i = 0; i < n; i += 10) bToggled("t" + i); },
    toggleAll() { bAll(); },
    remove() { for (const o of offs) o(); offs = []; for (const r of rows) clearNode(r); rows = []; bCleared(); },
    reset() { rowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls, countCalls, lastCount, size: scope.getState($todos).ids.length }; },
  };
});
