import { action, atom, batch, computed, notify, type Atom } from "@reatom/core";
import { register, registerTodos } from "../idiomatic";
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;
// Reatom notifies subscribers in a microtask; batch(fn, true) flushes synchronously so the work is timed.
register("events", "reatom", (n) => {
  let counters: Atom<number>[], tick: (a: number) => void, offs: (() => void)[] = [], calls = 0;
  return { prime: true,
    build() {
      counters = Array.from({ length: M }, () => atom(0));
      tick = action((a: number) => { for (const c of counters) c.set(c() + a); });
      for (const c of counters) offs.push(c.subscribe(() => { calls++; }));
      notify();
    },
    run() { calls = 0; for (let i = 0; i < n; i++) batch(() => tick(1), true); },
    check() { assert(calls === n * M && counters[3]() === 2 * n, `events ${calls} ${counters[3]()}`); },
    teardown() { for (const o of offs) o(); offs = []; notify(); } };
});

interface Todo { id: string; title: Atom<string>; done: Atom<boolean> }
registerTodos("reatom", (n) => {
  const list = atom<Todo[]>([]);
  const doneCount = computed(() => { let c = 0; for (const t of list()) if (t.done()) c++; return c; });
  const toggle = action((t: Todo) => { t.done.set(!t.done()); });
  const toggleAll = action(() => { for (const t of list()) t.done.set(!t.done()); });
  let offs: (() => void)[] = [], rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i }));
  return {
    create() {
      batch(() => {
        list.set(data.map((d) => ({ id: d.id, title: atom(d.title), done: atom(false) })));
        for (const t of list()) { let first = true; offs.push(t.done.subscribe(() => { if (first) { first = false; return; } rowCalls++; })); }
        offs.push(doneCount.subscribe((v) => { lastCount = v; countCalls++; }));
      }, true);
    },
    toggleTenth() { const l = list(); for (let i = 0; i < n; i += 10) batch(() => toggle(l[i]), true); },
    toggleAll() { batch(() => toggleAll(), true); },
    remove() { batch(() => { for (const o of offs) o(); offs = []; list.set([]); }, true); },
    reset() { rowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls, countCalls, lastCount, size: list().length }; },
  };
});
