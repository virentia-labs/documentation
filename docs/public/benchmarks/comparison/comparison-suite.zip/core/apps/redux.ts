import { configureStore, createEntityAdapter, createSlice, createSelector, type EntityState } from "@reduxjs/toolkit";
import { legacy_createStore as createStore } from "redux";
import { register, registerTodos } from "../idiomatic";
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;
register("events", "redux", (n) => {
  let store: any, offs: (() => void)[] = [], calls = 0;
  return { prime: true,
    build() {
      store = createStore((s: { counters: number[] } = { counters: new Array(M).fill(0) }, a: any) =>
        a.type === "tick" ? { counters: s.counters.map((c) => c + a.amount) } : s);
      for (let i = 0; i < M; i++) { const sel = (s: any) => s.counters[i]; let last = sel(store.getState());
        offs.push(store.subscribe(() => { const v = sel(store.getState()); if (v !== last) { last = v; calls++; } })); }
    },
    run() { calls = 0; for (let i = 0; i < n; i++) store.dispatch({ type: "tick", amount: 1 }); },
    check() { assert(calls === n * M && store.getState().counters[3] === 2 * n, `events ${calls}`); },
    teardown() { for (const o of offs) o(); offs = []; } };
});

// Redux Toolkit (the officially recommended way): entity adapter + Immer reducers + memoized selectors.
interface Todo { id: string; title: string; done: boolean }
const adapter = createEntityAdapter<Todo>();
const slice = createSlice({
  name: "todos",
  initialState: adapter.getInitialState(),
  reducers: {
    added: adapter.addMany,
    toggled(state, a: { payload: string }) { const t = state.entities[a.payload]; t.done = !t.done; },
    toggledAll(state) { for (const id of state.ids) { const t = state.entities[id]; t.done = !t.done; } },
    cleared: adapter.removeAll,
  },
});
const { added, toggled, toggledAll, cleared } = slice.actions;
registerTodos("redux", (n) => {
  const store = configureStore({ reducer: { todos: slice.reducer }, middleware: (g) => g({ serializableCheck: false, immutableCheck: false }) });
  type RS = ReturnType<typeof store.getState>;
  const selectAll = adapter.getSelectors((s: RS) => s.todos).selectAll;
  const selectDone = createSelector([selectAll], (all) => { let c = 0; for (const t of all) if (t.done) c++; return c; });
  let offs: (() => void)[] = [], rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i, done: false }));
  const sub = <T,>(sel: (s: RS) => T, fn: (v: T) => void) => { let last = sel(store.getState()); return store.subscribe(() => { const v = sel(store.getState()); if (v !== last) { last = v; fn(v); } }); };
  return {
    create() {
      store.dispatch(added(data.map((d) => ({ ...d }))));
      for (const id of store.getState().todos.ids) offs.push(sub((s) => s.todos.entities[id]?.done, () => { rowCalls++; }));
      lastCount = selectDone(store.getState());
      offs.push(sub(selectDone, (v) => { lastCount = v; countCalls++; }));
    },
    toggleTenth() { for (let i = 0; i < n; i += 10) store.dispatch(toggled("t" + i)); },
    toggleAll() { store.dispatch(toggledAll()); },
    remove() { for (const o of offs) o(); offs = []; store.dispatch(cleared()); },
    reset() { rowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls, countCalls, lastCount, size: store.getState().todos.ids.length }; },
  };
});
