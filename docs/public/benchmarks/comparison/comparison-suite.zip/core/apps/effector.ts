import { createEvent, createStore, clearNode, type Store } from "effector";
import { register, registerTodos } from "../idiomatic";
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const M = 10;
register("events", "effector", (n) => {
  let counters: Store<number>[], tick: (a: number) => void, offs: (() => void)[] = [], calls = 0, nodes: any[] = [];
  return { prime: true,
    build() {
      const ev = createEvent<number>(); tick = ev; nodes.push(ev);
      counters = Array.from({ length: M }, () => { const s = createStore(0).on(ev, (x, a) => x + a); nodes.push(s); return s; });
      for (const c of counters) { let first = true; const u = c.watch(() => { if (first) { first = false; return; } calls++; }); offs.push(() => u()); }
    },
    run() { calls = 0; for (let i = 0; i < n; i++) tick(1); },
    check() { assert(calls === n * M && counters[3].getState() === 2 * n, `events ${calls} ${counters[3].getState()}`); },
    teardown() { for (const o of offs) o(); offs = []; for (const x of nodes) clearNode(x); nodes = []; } };
});

// Normalized list store (ids + byId), immutable updates; per-row derived store = useStoreMap-like.
interface Todo { id: string; title: string; done: boolean }
interface S { ids: string[]; byId: Record<string, Todo> }
registerTodos("effector", (n) => {
  const added = createEvent<Todo[]>(), toggled = createEvent<string>(), toggledAll = createEvent<void>(), cleared = createEvent<void>();
  const $todos = createStore<S>({ ids: [], byId: {} })
    .on(added, (s, list) => { const byId = { ...s.byId }; const ids = s.ids.slice(); for (const t of list) { byId[t.id] = t; ids.push(t.id); } return { ids, byId }; })
    .on(toggled, (s, id) => ({ ids: s.ids, byId: { ...s.byId, [id]: { ...s.byId[id], done: !s.byId[id].done } } }))
    .on(toggledAll, (s) => { const byId: Record<string, Todo> = {}; for (const id of s.ids) { const t = s.byId[id]; byId[id] = { ...t, done: !t.done }; } return { ids: s.ids, byId }; })
    .on(cleared, () => ({ ids: [], byId: {} }));
  const $doneCount = $todos.map((s) => { let c = 0; for (const id of s.ids) if (s.byId[id].done) c++; return c; });
  let offs: (() => void)[] = [], rows: any[] = [], rowCalls = 0, countCalls = 0, lastCount = -1;
  const data = Array.from({ length: n }, (_, i) => ({ id: "t" + i, title: "todo " + i, done: false }));
  return {
    create() {
      added(data.map((d) => ({ ...d })));
      for (const id of $todos.getState().ids) {
        const $row = $todos.map((s) => s.byId[id]?.done ?? null); rows.push($row);
        let first = true; const u = $row.watch(() => { if (first) { first = false; return; } rowCalls++; }); offs.push(() => u());
      }
      const u = $doneCount.watch((v) => { lastCount = v; countCalls++; }); offs.push(() => u());
    },
    toggleTenth() { for (let i = 0; i < n; i += 10) toggled("t" + i); },
    toggleAll() { toggledAll(); },
    remove() { for (const o of offs) o(); offs = []; for (const r of rows) clearNode(r); rows = []; cleared(); },
    reset() { rowCalls = 0; countCalls = 0; },
    stats() { return { rowCalls, countCalls, lastCount, size: $todos.getState().ids.length }; },
  };
});
