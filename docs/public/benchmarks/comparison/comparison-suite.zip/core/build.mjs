import fs from "node:fs";
import path from "node:path";
import { bundle } from "../build-lib.mjs";
const here = path.dirname(new URL(import.meta.url).pathname);
fs.mkdirSync(path.join(here, "dist"), { recursive: true });
const libs = process.argv.slice(2).length ? process.argv.slice(2) : ["virentia", "virentia-scoped", "virentia-auto", "virentia-setup", "virentia-noindex", "mobx", "effector", "effector-scope", "effector-named", "effector-scope-named", "reatom", "redux"];
for (const lib of libs) {
  const base = lib.split("-")[0];
  const adapterLib = lib.replace(/-named$/, "");
  const adapterFile = fs.existsSync(path.join(here, `adapters/${adapterLib}.ts`)) ? `./adapters/${adapterLib}` : `./adapters/${base}`;
  const appFile = fs.existsSync(path.join(here, `apps/${adapterLib}.ts`)) ? `./apps/${adapterLib}.ts` : `./apps/${base}.ts`;
  const entry = path.join(here, `.entry-${lib}.ts`);
  fs.writeFileSync(entry, `import { adapter } from ${JSON.stringify(adapterFile)};\n` +
    (fs.existsSync(path.join(here, appFile)) ? `import ${JSON.stringify(appFile.replace(/\.ts$/, ""))};\n` : "") +
    `import { main } from "./harness";\nawait main(adapter, ${JSON.stringify(lib)}, ${JSON.stringify(base)});\n`);
  await bundle(entry, path.join(here, `dist/${lib}.mjs`), { platform: "node", define: {
    OBSERVE_MODE: JSON.stringify({ "virentia-auto": "auto", "virentia-scoped": "scoped", "virentia-setup": "setup" }[lib] ?? "subscribe"),
    TODO_INDEX: String(lib !== "virentia-noindex"),
    EFFECTOR_NAMED: String(lib.endsWith("-named")),
  } });
  fs.rmSync(entry);
  console.log("built", lib, (fs.statSync(path.join(here, `dist/${lib}.mjs`)).size / 1024).toFixed(1), "KiB");
}
