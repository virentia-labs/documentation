// Common adapter for graph-shaped scenarios. Every operation must be fully propagated
// (all derived values recomputed, all observers called) when the call returns.
export type Src = unknown;
export type Node = unknown;
export interface Adapter {
  name: string;
  version: string;
  /** Called before building a graph (e.g. create the scope / store). */
  begin(): void;
  signal(initial: number): Src;
  computed1(a: Node, fn: (x: number) => number): Node;
  computed2(a: Node, b: Node, fn: (x: number, y: number) => number): Node;
  computedN(deps: Node[], fn: (values: number[]) => number): Node;
  /** Observer of a node (like a UI binding / subscription). Returns unsubscribe. */
  observe(node: Node, fn: (v: number) => void): () => void;
  /** Finish building (e.g. Redux creates its store here). */
  commit(): void;
  /** One complete external update of a single source. */
  write(s: Src, v: number): void;
  /** One complete external update writing many sources; observers notified after. */
  batch(fn: (set: (s: Src, v: number) => void) => void): void;
  /** Untracked read of the current value. */
  read(node: Node): number;
  /** Release everything created since begin(). */
  end(): void;
}
