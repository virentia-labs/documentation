// Node-side harness: runs one (adapter, scenario, size) series in this process and prints JSON.
import type { Adapter } from "./adapter";
import { scenarios } from "./scenarios";
import { idiomatic, extraStats } from "./idiomatic";
declare const gc: () => void;
declare const ADAPTER: Adapter;
// BENCH_NOGC=1: no forced full GC around timed runs. A forced (testing) GC also discards
// optimized code whose embedded maps/objects it collects, unlike ordinary GCs.
const noGC = typeof process !== "undefined" && process.env.BENCH_NOGC === "1";
const forceGC = () => { if (!noGC) { gc(); gc(); } };

export async function main(adapter: Adapter, lib: string, base = lib) {
  const args = Object.fromEntries(process.argv.slice(2).map((a) => a.split("=")));
  const scenario = args.scenario as string, n = Number(args.n);
  const warmup = Number(args.warmup ?? 5), rounds = Number(args.rounds ?? 10);
  const samples: number[] = [], heaps: number[] = [];
  let error: string | undefined;
  try {
    for (let r = 0; r < warmup + rounds; r++) {
      let ms: number, heapMB = NaN;
      if (scenario in scenarios) {
        const c = scenarios[scenario](adapter, n);
        c.build();
        if (scenario !== "create" && scenario !== "cellxBuild" && scenario !== "dispose") { c.run(-1); }   // prime (untimed)
        forceGC();
        const h0 = process.memoryUsage().heapUsed;
        const t0 = performance.now();
        c.run(r);
        ms = performance.now() - t0;
        forceGC();
        heapMB = (process.memoryUsage().heapUsed - h0) / 1048576;
        c.check(r);
        c.teardown();
      } else {
        const impl = idiomatic[scenario]?.[lib] ?? idiomatic[scenario]?.[base];
        if (!impl) throw new Error(`no idiomatic implementation of ${scenario} for ${lib}`);
        const c = impl(n);
        await c.build?.();
        if (c.prime) await c.run(-1);
        forceGC();
        const h0 = process.memoryUsage().heapUsed;
        const t0 = performance.now();
        const p = c.run(r);
        if (p && typeof (p as Promise<void>).then === "function") await p;
        ms = performance.now() - t0;
        forceGC();
        heapMB = (process.memoryUsage().heapUsed - h0) / 1048576;
        await c.check?.(r);
        await c.teardown?.();
      }
      if (r >= warmup) { samples.push(ms); heaps.push(heapMB); }
    }
  } catch (e) {
    error = String((e as Error)?.stack ?? e).slice(0, 600);
  }
  process.stdout.write(JSON.stringify({ lib, version: adapter.version, scenario, n, warmup, rounds, samples, heaps, error, extra: extraStats, node: process.version }) + "\n");
}
