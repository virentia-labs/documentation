// Orchestrates core runs: one fresh Node process per (lib, scenario, size, repetition); libs rotated.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
const here = path.dirname(new URL(import.meta.url).pathname);
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.split("=")));
const out = args.out ?? path.join(here, "../results/core-raw.jsonl");
const P = Number(args.p ?? 3);
const graphLibs = ["virentia", "virentia-auto", "mobx", "effector", "effector-scope", "reatom", "redux"];
const plan = [
  // [scenario, sizes, libs]
  ["create", [1000, 10000], graphLibs],
  ["dispose", [1000, 10000], graphLibs],
  ["updateTenth", [1000, 10000], graphLibs],
  ["batchAll", [1000, 10000], graphLibs],
  ["fanout", [1000, 10000], graphLibs],
  ["fanin", [1000, 10000], graphLibs],
  ["chain", [100, 500], graphLibs],
  ["cellxBuild", [1000, 2500], graphLibs],
  ["cellxUpdate", [1000, 2500], graphLibs],
  ["events", [1000, 10000], ["virentia", "mobx", "effector", "effector-scope", "reatom", "redux"]],
  ["eventsInScope", [1000, 10000], ["virentia"]],
  ["todosCreate", [1000, 10000], ["virentia", "virentia-noindex", "virentia-auto", "mobx", "effector", "effector-scope", "reatom", "redux"]],
  ["todosToggleTenth", [1000, 10000], ["virentia", "virentia-noindex", "virentia-auto", "mobx", "effector", "effector-scope", "reatom", "redux"]],
  ["todosToggleAll", [1000, 10000], ["virentia", "virentia-noindex", "virentia-auto", "mobx", "effector", "effector-scope", "reatom", "redux"]],
  ["todosRemove", [1000, 10000], ["virentia", "virentia-noindex", "virentia-auto", "mobx", "effector", "effector-scope", "reatom", "redux"]],
];
const only = args.only?.split(",");
const libsOverride = args.libs?.split(",");
const skip = new Set((args.skip ?? "").split(",").filter(Boolean)); // "scenario:n" pairs already done
const exclude = new Set((args.exclude ?? "").split(",").filter(Boolean)); // "lib@scenario:n" triples to skip
let k = 0;
for (const [scenario, sizes, planLibs] of plan) {
  const libs = libsOverride ?? planLibs;
  if (only && !only.includes(scenario)) continue;
  for (const n of sizes) {
    if (skip.has(`${scenario}:${n}`)) continue;
    const large = n === sizes[1];
    const heavy = large && scenario.startsWith("cellx");
    const warmup = heavy ? 1 : large ? 2 : 5, rounds = heavy ? 3 : large ? 4 : 10;
    for (let p = 0; p < P; p++) {
      const order = libs.slice(p % libs.length).concat(libs.slice(0, p % libs.length));
      for (const lib of order) {
        if (exclude.has(`${lib}@${scenario}:${n}`)) continue;
        const t = Date.now();
        const r = spawnSync(process.execPath, ["--expose-gc", "--stack-size=984", path.join(here, `dist/${lib}.mjs`), `scenario=${scenario}`, `n=${n}`, `warmup=${warmup}`, `rounds=${rounds}`], { encoding: "utf8", timeout: 600000, maxBuffer: 1 << 26 });
        let line = r.stdout.trim().split("\n").pop();
        let rec;
        try { rec = JSON.parse(line); } catch { rec = { lib, scenario, n, error: `exit ${r.status} ${r.signal ?? ""} ${(r.stderr || "").slice(0, 300)}`, samples: [] }; }
        rec.rep = p; rec.wallS = (Date.now() - t) / 1000;
        fs.appendFileSync(out, JSON.stringify(rec) + "\n");
        const med = rec.samples.length ? rec.samples.slice().sort((a, b) => a - b)[Math.floor(rec.samples.length / 2)] : NaN;
        console.log(`${++k} ${scenario} n=${n} rep=${p} ${lib.padEnd(16)} median ${med.toFixed(2)} ms ${rec.error ? "ERROR " + rec.error.split("\n")[0].slice(0, 120) : ""} (${rec.wallS.toFixed(1)}s)`);
      }
    }
  }
}
console.log("DONE");
