// Graph scenarios over the common adapter. Each returns { build, run, check } closures.
import type { Adapter, Node, Src } from "./adapter";

export interface Case {
  /** untimed unless the scenario measures creation */
  build(): void;
  /** the timed operation for this round */
  run(round: number): void;
  /** validate after run (untimed), throws on mismatch */
  check(round: number): void;
  teardown(): void;
}
let observed = 0, observedSum = 0;
const obs = (v: number) => { observed++; observedSum += v; };
const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };

/** N independent sources, each -> computed(x*2) -> observer. */
function rowsGraph(a: Adapter, n: number) {
  const src: Src[] = new Array(n), der: Node[] = new Array(n);
  a.begin();
  for (let i = 0; i < n; i++) { src[i] = a.signal(i); der[i] = a.computed1(src[i], (x) => x * 2); }
  for (let i = 0; i < n; i++) a.observe(der[i], obs);
  a.commit();
  return { src, der };
}

export const scenarios: Record<string, (a: Adapter, n: number) => Case> = {
  // Creation: build + activate N (source -> derived -> observer). Timed: the build itself.
  create(a, n) {
    let g: ReturnType<typeof rowsGraph> | undefined;
    return {
      build() {},
      run() { g = rowsGraph(a, n); },
      check(round) {
        observed = 0;
        const k = Math.min(n - 1, 7);
        a.write(g!.src[k], 1000 + round);
        assert(a.read(g!.der[k]) === 2 * (1000 + round), `create: derived value ${a.read(g!.der[k])}`);
        assert(observed === 1, `create: observer calls ${observed}`);
      },
      teardown() { a.end(); g = undefined; },
    };
  },
  // Dispose: unsubscribe everything created by the build (timed).
  dispose(a, n) {
    return {
      build() { rowsGraph(a, n); },
      run() { a.end(); },
      check() {},
      teardown() {},
    };
  },
  // 10% of sources updated, each as a separate complete update.
  updateTenth(a, n) {
    let g: ReturnType<typeof rowsGraph>;
    return {
      build() { g = rowsGraph(a, n); },
      run(round) { observed = 0; for (let i = 0; i < n; i += 10) a.write(g.src[i], round * 7 + i); },
      check(round) {
        assert(observed === Math.ceil(n / 10), `updateTenth: observer calls ${observed} != ${Math.ceil(n / 10)}`);
        assert(a.read(g.der[10]) === 2 * (round * 7 + 10), "updateTenth: wrong derived");
      },
      teardown() { a.end(); },
    };
  },
  // All sources updated in one batch/transaction; each observer must fire once.
  batchAll(a, n) {
    let g: ReturnType<typeof rowsGraph>;
    return {
      build() { g = rowsGraph(a, n); },
      run(round) { observed = 0; a.batch((set) => { for (let i = 0; i < n; i++) set(g.src[i], round * 3 + i + 1); }); },
      check(round) {
        assert(observed === n, `batchAll: observer calls ${observed} != ${n}`);
        assert(a.read(g.der[n - 1]) === 2 * (round * 3 + n), "batchAll: wrong derived");
      },
      teardown() { a.end(); },
    };
  },
  // One source -> N derived -> N observers; 10 updates of the source.
  fanout(a, n) {
    let s: Src; const der: Node[] = [];
    return {
      build() {
        a.begin(); s = a.signal(0);
        for (let i = 0; i < n; i++) { const k = i; der.push(a.computed1(s, (x) => x + k)); }
        for (const d of der) a.observe(d, obs);
        a.commit();
      },
      run(round) { observed = 0; for (let j = 1; j <= 10; j++) a.write(s, round * 100 + j); },
      check(round) {
        assert(observed === 10 * n, `fanout: observer calls ${observed} != ${10 * n}`);
        assert(a.read(der[n - 1]) === round * 100 + 10 + n - 1, "fanout: wrong derived");
      },
      teardown() { a.end(); der.length = 0; },
    };
  },
  // One source -> N derived -> one aggregate (sum) -> observer; 10 updates.
  fanin(a, n) {
    let s: Src; let sum: Node;
    return {
      build() {
        a.begin(); s = a.signal(0);
        const der: Node[] = [];
        for (let i = 0; i < n; i++) { const k = i; der.push(a.computed1(s, (x) => x + k)); }
        sum = a.computedN(der, (vals) => { let t = 0; for (const v of vals) t += v; return t; });
        a.observe(sum, obs);
        a.commit();
      },
      run(round) { observed = 0; for (let j = 1; j <= 10; j++) a.write(s, round * 100 + j); },
      check(round) {
        assert(observed === 10, `fanin: observer calls ${observed}`);
        const x = round * 100 + 10;
        assert(a.read(sum) === n * x + (n * (n - 1)) / 2, `fanin: wrong sum ${a.read(sum)}`);
      },
      teardown() { a.end(); },
    };
  },
  // Deep chain of N derived nodes; observer at the tail; 10 updates.
  chain(a, n) {
    let s: Src; let tail: Node;
    return {
      build() {
        a.begin(); s = a.signal(0); let prev: Node = s;
        for (let i = 0; i < n; i++) prev = a.computed1(prev, (x) => x + 1);
        tail = prev; a.observe(tail, obs); a.commit();
      },
      run(round) { observed = 0; for (let j = 1; j <= 10; j++) a.write(s, round * 100 + j); },
      check(round) {
        assert(observed === 10, `chain: observer calls ${observed}`);
        assert(a.read(tail) === round * 100 + 10 + n, `chain: wrong tail ${a.read(tail)}`);
      },
      teardown() { a.end(); },
    };
  },
  // cellx benchmark (N layers of 4 nodes, every node observed). Timed: build.
  cellxBuild(a, n) {
    return {
      build() {},
      run() { cellx(a, n); },
      check() {},
      teardown() { a.end(); },
    };
  },
  // cellx: timed batch update of the 4 sources + reading the 4 outputs.
  cellxUpdate(a, n) {
    let g: ReturnType<typeof cellx>;
    return {
      build() { g = cellx(a, n); },
      run(round) {
        // prime (round -1) moves the sources to A; every timed round then moves them to B.
        const v = round < 0 ? [4, 3, 2, 1] : [1, 2, 3, 4];
        a.batch((set) => { set(g.start[0], v[0]); set(g.start[1], v[1]); set(g.start[2], v[2]); set(g.start[3], v[3]); });
        g.last = g.end.map((x) => a.read(x));
      },
      check(round) {
        const v = [1, 2, 3, 4];
        const exp = cellxReference(n, v);
        assert(g.last!.join() === exp.join(), `cellx: ${g.last} != ${exp}`);
      },
      teardown() { a.end(); },
    };
  },
};

function cellx(a: Adapter, layers: number) {
  a.begin();
  const start = [a.signal(1), a.signal(2), a.signal(3), a.signal(4)];
  let l: Node[] = start;
  const all: Node[] = [];
  for (let i = 0; i < layers; i++) {
    const m = l;
    const next = [
      a.computed1(m[1], (b) => b),
      a.computed2(m[0], m[2], (x, c) => x - c),
      a.computed2(m[1], m[3], (b, d) => b + d),
      a.computed1(m[2], (c) => c),
    ];
    all.push(...next);
    l = next;
  }
  for (const node of all) a.observe(node, obs);
  a.commit();
  return { start, end: l, last: undefined as number[] | undefined };
}
function cellxReference(layers: number, v: number[]) {
  let [x, b, c, d] = v;
  for (let i = 0; i < layers; i++) [x, b, c, d] = [b, x - c, b + d, c];
  return [x, b, c, d];
}
