import { combine, createEvent, createStore, createWatch, fork, launch, scopeBind, clearNode, type EventCallable, type Scope, type Store } from "effector";
import type { Adapter } from "../adapter";
// Forked effector (the SSR/test setup): same graph, values live in a scope; parity with Virentia's always-scoped model.
interface S { store: Store<number>; set: EventCallable<number>; bound?: (v: number) => void }
let scope: Scope;
let created: unknown[] = [];
let unsubs: (() => void)[] = [];
declare const EFFECTOR_NAMED: boolean;
const cfg = (): any => (EFFECTOR_NAMED ? { name: "n" } : undefined);
const release = () => { for (const c of created) clearNode(c as any); created = []; };
const isSrc = (x: unknown): x is S => typeof x === "object" && x !== null && "set" in x;
const st = (x: unknown) => (isSrc(x) ? x.store : (x as Store<number>));
export const adapter: Adapter = {
  name: "effector-scope",
  version: "23.4.4 (fork)",
  begin() { release(); unsubs = []; scope = fork(); },
  signal(v) { const set = createEvent<number>(); const store = createStore(v, { skipVoid: false }).on(set, (_, x) => x); created.push(store, set); return { store, set }; },
  computed1: (a, fn) => { const c = EFFECTOR_NAMED ? st(a).map(fn, cfg()) : st(a).map(fn); created.push(c); return c; },
  computed2: (a, b, fn) => { const c = EFFECTOR_NAMED ? (combine as any)(st(a), st(b), fn, cfg()) : combine(st(a), st(b), fn); created.push(c); return c; },
  computedN: (deps, fn) => { const c = EFFECTOR_NAMED ? (combine as any)(deps.map(st), (vals: number[]) => fn(vals), cfg()) : combine(deps.map(st), (vals) => fn(vals as number[])); created.push(c); return c; },
  observe(node, fn) { fn(scope.getState(st(node))); const sub = createWatch({ unit: st(node), fn, scope }); const off = () => sub(); unsubs.push(off); return off; },
  commit() {},
  write(s, v) { const src = s as S; (src.bound ??= scopeBind(src.set, { scope })) (v); },
  batch(fn) {
    const targets: unknown[] = [], params: number[] = [];
    fn((s, v) => { targets.push((s as S).set); params.push(v); });
    launch({ target: targets as any, params, defer: false, scope } as any);
  },
  read: (node) => scope.getState(st(node)),
  end() { for (const u of unsubs) u(); unsubs = []; },
};
