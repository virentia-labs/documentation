import { legacy_createStore as createStore, type Store } from "redux";
import { createSelector } from "reselect";
import type { Adapter } from "../adapter";
// Redux idiom: one immutable state tree, memoized selectors (reselect), useSelector-like subscribers.
type State = { v: number[] };
type Sel = (s: State) => number;
let initial: number[] = [];
let store: Store<State, any> | undefined;
let pending: { i: number; v: number }[] | undefined;
let unsubs: (() => void)[] = [];
const reducer = (state: State = { v: initial }, action: any): State => {
  switch (action.type) {
    case "set": { const v = state.v.slice(); v[action.i] = action.value; return { v }; }
    case "setMany": { const v = state.v.slice(); for (const e of action.entries) v[e.i] = e.v; return { v }; }
    default: return state;
  }
};
const ensure = () => (store ??= createStore(reducer));
export const adapter: Adapter = {
  name: "redux",
  version: "redux 5.0.1 + reselect 5.3.0",
  begin() { initial = []; store = undefined; unsubs = []; },
  signal(v) { const i = initial.push(v) - 1; const sel: Sel & { i?: number } = (s) => s.v[i]; sel.i = i; return sel; },
  computed1: (a, fn) => createSelector([a as Sel], fn),
  computed2: (a, b, fn) => createSelector([a as Sel, b as Sel], fn),
  computedN: (deps, fn) => createSelector(deps as Sel[], (...vals: number[]) => fn(vals)),
  observe(node, fn) {
    const s = ensure(); const sel = node as Sel;
    let last = sel(s.getState()); fn(last);
    const off = s.subscribe(() => { const v = sel(s.getState()); if (v !== last) { last = v; fn(v); } });
    unsubs.push(off); return off;
  },
  commit() { ensure(); },
  write(s, v) { ensure().dispatch({ type: "set", i: (s as { i: number }).i, value: v }); },
  batch(fn) { const entries: { i: number; v: number }[] = []; fn((s, v) => entries.push({ i: (s as { i: number }).i, v })); ensure().dispatch({ type: "setMany", entries }); },
  read: (node) => (node as Sel)(ensure().getState()),
  end() { for (const u of unsubs) u(); unsubs = []; store = undefined; initial = []; },
};
