import { computed, configure, observable, reaction, runInAction, type IComputedValue, type IObservableValue } from "mobx";
import type { Adapter } from "../adapter";
configure({ enforceActions: "never" });
type V = IObservableValue<number> | IComputedValue<number>;
let unsubs: (() => void)[] = [];
export const adapter: Adapter = {
  name: "mobx",
  version: "7.1.1",
  begin() { unsubs = []; },
  signal: (v) => observable.box(v, { deep: false }),
  computed1: (a, fn) => computed(() => fn((a as V).get())),
  computed2: (a, b, fn) => computed(() => fn((a as V).get(), (b as V).get())),
  computedN: (deps, fn) => computed(() => fn((deps as V[]).map((d) => d.get()))),
  observe(node, fn) { const off = reaction(() => (node as V).get(), fn, { fireImmediately: true }); unsubs.push(off); return off; },
  commit() {},
  write(s, v) { (s as IObservableValue<number>).set(v); },
  batch(fn) { runInAction(() => fn((s, v) => (s as IObservableValue<number>).set(v))); },
  read: (node) => (node as V).get(),
  end() { for (const u of unsubs) u(); unsubs = []; },
};
