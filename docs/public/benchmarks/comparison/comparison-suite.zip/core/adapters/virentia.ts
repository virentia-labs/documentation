import { computed, event, reaction, scope, scoped, store, type Scope, type Store, type StoreWritable } from "@virentia/core";
import type { Adapter } from "../adapter";

let sc: Scope;
const batchEvent = event<(set: (s: unknown, v: number) => void) => void>();
// Writes inside a reaction body are committed as one transaction.
reaction({ on: batchEvent, run: (fn) => fn((s, v) => { (s as StoreWritable<number>).value = v; }) });
let unsubs: (() => void)[] = [];
declare const OBSERVE_MODE: string;

export const adapter: Adapter = {
  name: "virentia",
  version: "@virentia/core 0.11.2 + working tree",
  begin() { sc = scope(); unsubs = []; },
  signal: (v) => store(v),
  // Single-source derivation via the store's own .map (static dependency), like effector's .map.
  computed1: (a, fn) => (a as Store<number>).map(fn),
  computed2: (a, b, fn) => computed(() => fn((a as Store<number>).value, (b as Store<number>).value)),
  computedN: (deps, fn) => computed(() => fn((deps as Store<number>[]).map((d) => d.value))),
  observe(node, fn) {
    let off: () => void;
    switch (OBSERVE_MODE) {
      case "subscribe": // scope-less store subscription, activated in the app scope first
        scoped(sc, () => (node as Store<number>).value);
        off = (node as Store<number>).subscribe((v) => fn(v));
        break;
      case "reaction": { // scope-less explicit reaction
        const r = reaction({ on: node as Store<number>, run: (v: number) => fn(v) });
        off = () => r.stop();
        break;
      }
      case "scoped": { // explicit reaction bound to the app scope (node materialized in the scope first)
        scoped(sc, () => (node as Store<number>).value);
        const r = reaction({ scope: sc, on: node as Store<number>, run: (v: number) => fn(v) });
        off = () => r.stop();
        break;
      }
      default: { // auto-tracking reaction in the app scope
        const r = reaction({ scope: sc, run: () => fn((node as Store<number>).value) });
        off = () => r.stop();
      }
    }
    unsubs.push(off);
    return off;
  },
  commit() {},
  write(s, v) { scoped(sc, () => { (s as StoreWritable<number>).value = v; }); },
  batch(fn) { scoped(sc, () => batchEvent(fn)); },
  read: (node) => scoped(sc, () => (node as Store<number>).value),
  end() { for (const u of unsubs) u(); unsubs = []; },
};
