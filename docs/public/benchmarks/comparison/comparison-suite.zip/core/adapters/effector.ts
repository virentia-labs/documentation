import { combine, createEvent, createStore, launch, clearNode, type EventCallable, type Store } from "effector";
import type { Adapter } from "../adapter";
// Global (non-forked) effector, the usual client-side setup.
interface S { store: Store<number>; set: EventCallable<number> }
let created: unknown[] = [];
let unsubs: (() => void)[] = [];
declare const EFFECTOR_NAMED: boolean;
const cfg = (): any => (EFFECTOR_NAMED ? { name: "n" } : undefined);
const release = () => { for (const c of created) clearNode(c as any); created = []; };
const isSrc = (x: unknown): x is S => typeof x === "object" && x !== null && "set" in x;
const st = (x: unknown) => (isSrc(x) ? x.store : (x as Store<number>));
export const adapter: Adapter = {
  name: "effector",
  version: "23.4.4",
  begin() { release(); unsubs = []; },
  signal(v) { const set = createEvent<number>(); const store = createStore(v, { skipVoid: false }).on(set, (_, x) => x); const s = { store, set }; created.push(store, set); return s; },
  computed1: (a, fn) => { const c = EFFECTOR_NAMED ? st(a).map(fn, cfg()) : st(a).map(fn); created.push(c); return c; },
  computed2: (a, b, fn) => { const c = EFFECTOR_NAMED ? (combine as any)(st(a), st(b), fn, cfg()) : combine(st(a), st(b), fn); created.push(c); return c; },
  computedN: (deps, fn) => { const c = EFFECTOR_NAMED ? (combine as any)(deps.map(st), (vals: number[]) => fn(vals), cfg()) : combine(deps.map(st), (vals) => fn(vals as number[])); created.push(c); return c; },
  observe(node, fn) { const sub = st(node).watch(fn); const off = () => sub(); unsubs.push(off); return off; },
  commit() {},
  write(s, v) { (s as S).set(v); },
  batch(fn) {
    const targets: unknown[] = [], params: number[] = [];
    fn((s, v) => { targets.push((s as S).set); params.push(v); });
    launch({ target: targets as any, params, defer: false } as any);
  },
  read: (node) => st(node).getState(),
  end() { for (const u of unsubs) u(); unsubs = []; },
};
