import { atom, batch, computed, notify, type Atom } from "@reatom/core";
import type { Adapter } from "../adapter";
type A = Atom<number> | (() => number);
let unsubs: (() => void)[] = [];
export const adapter: Adapter = {
  name: "reatom",
  version: "@reatom/core 1001.3.0",
  begin() { unsubs = []; },
  signal: (v) => atom(v),
  computed1: (a, fn) => computed(() => fn((a as () => number)())),
  computed2: (a, b, fn) => computed(() => fn((a as () => number)(), (b as () => number)())),
  computedN: (deps, fn) => computed(() => fn((deps as (() => number)[]).map((d) => d()))),
  observe(node, fn) { const off = (node as Atom<number>).subscribe(fn); unsubs.push(off); return off; },
  commit() { notify(); },
  // Reatom defers notifications to a microtask; flush synchronously so the work is measured.
  write(s, v) { batch(() => { (s as Atom<number>).set(v); }, true); },
  batch(fn) { batch(() => fn((s, v) => (s as Atom<number>).set(v)), true); },
  read: (node) => (node as () => number)(),
  end() { for (const u of unsubs) u(); unsubs = []; notify(); },
};
