// Placeholder registry for library-specific (non-adapter) scenarios; filled in per library.
export interface IdiomaticCase {
  build?(): void | Promise<void>;
  prime?: boolean;
  run(round: number): void | Promise<void>;
  check?(round: number): void | Promise<void>;
  teardown?(): void | Promise<void>;
}
export const extraStats: Record<string, number> = {};
export const idiomatic: Record<string, Record<string, (n: number) => IdiomaticCase>> = {};
export function register(scenario: string, lib: string, f: (n: number) => IdiomaticCase) {
  (idiomatic[scenario] ??= {})[lib] = f;
}

const assert = (c: unknown, m: string) => { if (!c) throw new Error(m); };
export interface TodosImpl {
  create(): void;
  toggleTenth(): void;
  toggleAll(): void;
  remove(): void | Promise<void>;
  reset(): void;
  stats(): { rowCalls: number; countCalls: number; lastCount: number; size: number };
}
export function registerTodos(lib: string, make: (n: number) => TodosImpl) {
  register("todosCreate", lib, (n) => { const t = make(n); return {
    run() { t.create(); },
    check() { const s = t.stats(); assert(s.size === n && s.lastCount === 0, `todosCreate: ${JSON.stringify(s)}`); },
    teardown() { return t.remove(); } }; });
  register("todosToggleTenth", lib, (n) => { const t = make(n); return { prime: true,
    build() { t.create(); },
    run(round) { t.reset(); t.toggleTenth(); },
    check(round) { const s = t.stats(); const k = Math.ceil(n / 10);
      assert(s.rowCalls === k, `todosToggleTenth: ${JSON.stringify(s)}`);
      extraStats.aggregateNotifications = s.countCalls; extraStats.expectedAggregateNotifications = k;
      assert(s.lastCount === 0, `todosToggleTenth count: ${JSON.stringify(s)} round ${round}`); },
    teardown() { return t.remove(); } }; });
  register("todosToggleAll", lib, (n) => { const t = make(n); return { prime: true,
    build() { t.create(); },
    run() { t.reset(); t.toggleAll(); },
    check(round) { const s = t.stats();
      assert(s.rowCalls === n, `todosToggleAll: ${JSON.stringify(s)}`);
      extraStats.aggregateNotifications = s.countCalls; extraStats.expectedAggregateNotifications = 1;
      assert(s.lastCount === 0, `todosToggleAll count: ${JSON.stringify(s)}`); },
    teardown() { return t.remove(); } }; });
  register("todosRemove", lib, (n) => { const t = make(n); return {
    build() { t.create(); },
    run() { return t.remove(); },
    check() { const s = t.stats(); assert(s.size === 0, `todosRemove: ${JSON.stringify(s)}`); } }; });
}
